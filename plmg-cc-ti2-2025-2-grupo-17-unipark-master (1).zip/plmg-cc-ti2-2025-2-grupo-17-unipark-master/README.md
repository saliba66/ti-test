# [Unipark]

[O projeto desenvolvido pelo grupo tem como foco a criação de um software inteligente de gerenciamento de estacionamento universitário, chamado UniPark . A proposta busca solucionar a dificuldade de controle de vagas dentro da universidade, oferecendo uma plataforma que monitora em tempo real a entrada e saída de veículos, bem como a disponibilidade de vagas. O sistema integra diferentes perfis de usuários — como alunos, visitantes, funcionários e administradores — permitindo o cadastro, autenticação e gerenciamento personalizado de acessos e permissões.

Entre as principais funcionalidades, destacam-se o mapa interativo do estacionamento, o monitoramento por IA com leitura automática de placas, e o banco de dados relacional, responsável por armazenar e gerenciar informações sobre vagas, veículos e usuários. Além disso, o sistema foi projetado para garantir reservas automáticas para vagas especiais (PCD, funcionários e visitantes) e oferecer relatórios de uso para otimizar a gestão. Assim, o UniPark se apresenta como uma solução tecnológica eficiente que promove organização, acessibilidade e inovação no controle de estacionamentos universitários.]

## Alunos integrantes da equipe

* [Bruno Pais Moacir]
* [Gabriel Fonseca Saliba]
* [Gustavo Henrique]
* [João Vitor Lara]

## Professores responsáveis

* [Max do val]
* [Amália Soares]

## Instruções de utilização

[Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.]
