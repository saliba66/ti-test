// Gate control page - manual entry processing
export function render() {
    return `
        <div class="cancela-container">
            <div class="page-header">
                <h1>Controle de Cancela</h1>
                <p class="page-description">Processamento manual de entrada de veículos</p>
            </div>
            
            <div class="cancela-layout">
                <!-- Entry Form -->
                <div class="entry-section">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Entrada de Veículo</h3>
                        </div>
                        <form id="entryForm" class="entry-form">
                            <div class="form-group">
                                <label class="form-label" for="placaInput">
                                    Placa do Veículo <span class="required">*</span>
                                </label>
                                <input 
                                    type="text" 
                                    id="placaInput" 
                                    class="form-input" 
                                    placeholder="ABC-1234 ou ABC1D23" 
                                    required 
                                    maxlength="8"
                                    autocomplete="off"
                                    style="text-transform: uppercase;">
                                <small class="form-help">Digite apenas letras e números</small>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="categoriaSelect">
                                    Categoria <span class="required">*</span>
                                </label>
                                <select id="categoriaSelect" class="form-select" required>
                                    <option value="">Selecione a categoria</option>
                                    <option value="ALUNO">Aluno</option>
                                    <option value="FUNCIONARIO">Funcionário</option>
                                    <option value="PCD">PCD</option>
                                    <option value="VISITANTE_COMUM">Visitante Comum</option>
                                    <option value="VISITANTE_ESPECIAL">Visitante Especial</option>
                                </select>
                            </div>
                            
                            <div class="form-actions">
                                <button type="button" id="clearForm" class="btn btn-outline">
                                    Limpar
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <span class="btn-icon">🚧</span>
                                    Processar Entrada
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Result Display -->
                <div class="result-section">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Resultado do Processamento</h3>
                        </div>
                        <div id="resultDisplay" class="result-display">
                            <div class="no-result">
                                <div class="no-result-icon">🚧</div>
                                <p>Aguardando processamento...</p>
                                <small>Digite a placa e categoria para processar a entrada</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Info -->
                <div class="info-section">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Status do Estacionamento</h3>
                        </div>
                        <div class="parking-status">
                            <div class="status-item">
                                <span class="status-label">Vagas Livres:</span>
                                <span id="vagasLivres" class="status-value">0</span>
                            </div>
                            <div class="status-item">
                                <span class="status-label">Vagas Ocupadas:</span>
                                <span id="vagasOcupadas" class="status-value">0</span>
                            </div>
                            <div class="status-item">
                                <span class="status-label">Taxa de Ocupação:</span>
                                <span id="taxaOcupacao" class="status-value">0%</span>
                            </div>
                        </div>
                        
                        <div class="priority-info">
                            <h4>Regras de Prioridade</h4>
                            <ul class="priority-list">
                                <li><span class="priority-badge funcionario">Funcionário</span> → Vagas de funcionário ou comum</li>
                                <li><span class="priority-badge pcd">PCD</span> → Vagas PCD ou comum</li>
                                <li><span class="priority-badge visitante-especial">VIP</span> → Vagas VIP ou comum</li>
                                <li><span class="priority-badge aluno">Aluno</span> → Apenas vagas comuns</li>
                                <li><span class="priority-badge visitante">Visitante</span> → Apenas vagas comuns</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Entries -->
                <div class="recent-section">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Últimas Entradas</h3>
                        </div>
                        <div id="recentEntries" class="recent-entries">
                            <!-- Recent entries will be populated here -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

export function mount() {
    const store = window.app.getStore();
    const ui = window.app.getUI();
    
    // Initialize
    updateParkingStatus();
    updateRecentEntries();
    
    // Setup event listeners
    setupEventListeners();
    
    // Setup real-time updates
    store.subscribe('vagas', updateParkingStatus);
    store.subscribe('eventos', updateRecentEntries);
    
    function setupEventListeners() {
        const form = document.getElementById('entryForm');
        const placaInput = document.getElementById('placaInput');
        const clearBtn = document.getElementById('clearForm');
        
        // Form submission
        form.addEventListener('submit', handleFormSubmit);
        
        // Clear form
        clearBtn.addEventListener('click', clearForm);
        
        // Plate input formatting
        placaInput.addEventListener('input', (e) => {
            let value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
            
            // Auto-format with dash
            if (value.length >= 4) {
                if (value.length <= 7) {
                    value = value.slice(0, 3) + '-' + value.slice(3);
                } else {
                    value = value.slice(0, 3) + '-' + value.slice(3, 4) + value.slice(4, 5) + value.slice(5, 7);
                }
            }
            
            e.target.value = value;
        });
        
        // Enter key on select
        document.getElementById('categoriaSelect').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                form.dispatchEvent(new Event('submit'));
            }
        });
    }
    
    function handleFormSubmit(e) {
        e.preventDefault();
        
        const placaInput = document.getElementById('placaInput');
        const categoriaSelect = document.getElementById('categoriaSelect');
        
        const placa = placaInput.value.trim();
        const categoria = categoriaSelect.value;
        
        if (!placa || !categoria) {
            ui.showToast('Por favor, preencha todos os campos obrigatórios', 'error');
            return;
        }
        
        // Process entry
        processEntry(placa, categoria);
    }
    
    function processEntry(placa, categoria) {
        // Show loading
        showProcessingState();
        
        // Simulate processing delay for realism
        setTimeout(() => {
            const result = store.processarEntrada(placa, categoria);
            displayResult(result, placa, categoria);
            
            // Clear form if successful
            if (result.success) {
                setTimeout(() => {
                    clearForm();
                }, 3000);
            }
        }, 500);
    }
    
    function showProcessingState() {
        const resultDisplay = document.getElementById('resultDisplay');
        resultDisplay.innerHTML = `
            <div class="processing-state">
                <div class="processing-spinner"></div>
                <p>Processando entrada...</p>
                <small>Verificando disponibilidade de vagas</small>
            </div>
        `;
    }
    
    function displayResult(result, placa, categoria) {
        const resultDisplay = document.getElementById('resultDisplay');
        const timestamp = new Date().toLocaleString('pt-BR');
        
        if (result.success) {
            resultDisplay.innerHTML = `
                <div class="result-success">
                    <div class="result-icon">✅</div>
                    <div class="result-content">
                        <h4>ENTRADA AUTORIZADA</h4>
                        <div class="result-details">
                            <div class="detail-item">
                                <span class="detail-label">Placa:</span>
                                <span class="detail-value">${ui.formatPlaca(placa)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Categoria:</span>
                                <span class="detail-value">${getCategoriaTexto(categoria)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Vaga Atribuída:</span>
                                <span class="detail-value vaga-number">${result.vaga.numero}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Setor:</span>
                                <span class="detail-value">${result.vaga.setor}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Horário:</span>
                                <span class="detail-value">${timestamp}</span>
                            </div>
                        </div>
                        <div class="result-message">
                            ${result.motivo}
                        </div>
                    </div>
                </div>
            `;
            
            ui.showToast('Entrada autorizada com sucesso!', 'success');
            
        } else {
            resultDisplay.innerHTML = `
                <div class="result-error">
                    <div class="result-icon">❌</div>
                    <div class="result-content">
                        <h4>ENTRADA NEGADA</h4>
                        <div class="result-details">
                            <div class="detail-item">
                                <span class="detail-label">Placa:</span>
                                <span class="detail-value">${ui.formatPlaca(placa)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Categoria:</span>
                                <span class="detail-value">${getCategoriaTexto(categoria)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Horário:</span>
                                <span class="detail-value">${timestamp}</span>
                            </div>
                        </div>
                        <div class="result-message error">
                            <strong>Motivo:</strong> ${result.motivo}
                        </div>
                    </div>
                </div>
            `;
            
            ui.showToast(`Entrada negada: ${result.motivo}`, 'error');
        }
    }
    
    function clearForm() {
        document.getElementById('placaInput').value = '';
        document.getElementById('categoriaSelect').value = '';
        document.getElementById('placaInput').focus();
        
        const resultDisplay = document.getElementById('resultDisplay');
        resultDisplay.innerHTML = `
            <div class="no-result">
                <div class="no-result-icon">🚧</div>
                <p>Aguardando processamento...</p>
                <small>Digite a placa e categoria para processar a entrada</small>
            </div>
        `;
    }
    
    function updateParkingStatus() {
        const vagas = store.getVagas();
        const livres = vagas.filter(v => v.status === 'LIVRE').length;
        const ocupadas = vagas.filter(v => v.status === 'OCUPADA').length;
        const total = vagas.length;
        const taxa = total > 0 ? Math.round((ocupadas / total) * 100) : 0;
        
        document.getElementById('vagasLivres').textContent = livres;
        document.getElementById('vagasOcupadas').textContent = ocupadas;
        document.getElementById('taxaOcupacao').textContent = `${taxa}%`;
    }
    
    function updateRecentEntries() {
        const eventos = store.getEventos();
        const recentContainer = document.getElementById('recentEntries');
        
        // Get last 5 events
        const recentEvents = eventos
            .sort((a, b) => b.timestamp - a.timestamp)
            .slice(0, 5);
        
        if (recentEvents.length === 0) {
            recentContainer.innerHTML = '<p class="no-data">Nenhuma entrada recente</p>';
            return;
        }
        
        const entriesHTML = recentEvents.map(evento => {
            const timeAgo = getTimeAgo(evento.timestamp);
            const vaga = evento.vagaId ? store.getVagas().find(v => v.id === evento.vagaId) : null;
            
            return `
                <div class="recent-entry ${evento.decisao.toLowerCase()}">
                    <div class="entry-icon">
                        ${getEventIcon(evento.decisao)}
                    </div>
                    <div class="entry-info">
                        <div class="entry-main">
                            <span class="entry-placa">${ui.formatPlaca(evento.placa)}</span>
                            <span class="entry-badge badge badge-${getEventBadgeType(evento.decisao)}">
                                ${evento.decisao}
                            </span>
                        </div>
                        <div class="entry-details">
                            ${evento.motivo}
                            ${vaga ? ` - Vaga ${vaga.numero}` : ''}
                        </div>
                        <div class="entry-time">${timeAgo}</div>
                    </div>
                </div>
            `;
        }).join('');
        
        recentContainer.innerHTML = entriesHTML;
    }
    
    function getCategoriaTexto(categoria) {
        const categorias = {
            'ALUNO': 'Aluno',
            'FUNCIONARIO': 'Funcionário',
            'PCD': 'PCD',
            'VISITANTE_COMUM': 'Visitante Comum',
            'VISITANTE_ESPECIAL': 'Visitante Especial'
        };
        return categorias[categoria] || categoria;
    }
    
    function getEventIcon(decisao) {
        const icons = {
            'AUTORIZADO': '✅',
            'NEGADO': '❌',
            'MANUAL': '🔧'
        };
        return icons[decisao] || '📋';
    }
    
    function getEventBadgeType(decisao) {
        const types = {
            'AUTORIZADO': 'success',
            'NEGADO': 'error',
            'MANUAL': 'warning'
        };
        return types[decisao] || 'info';
    }
    
    function getTimeAgo(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        const minutes = Math.floor(diff / (60 * 1000));
        const hours = Math.floor(diff / (60 * 60 * 1000));
        
        if (minutes < 1) return 'agora mesmo';
        if (minutes < 60) return `${minutes}m atrás`;
        if (hours < 24) return `${hours}h atrás`;
        return new Date(timestamp).toLocaleDateString('pt-BR');
    }
}