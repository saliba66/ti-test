// Visitors management page - CRUD operations for visitors
export function render() {
    return `
        <div class="visitantes-container">
            <div class="page-header">
                <div class="header-content">
                    <h1>Gestão de Visitantes</h1>
                    <p class="page-description">Cadastro e controle de visitantes</p>
                </div>
                <div class="header-actions">
                    <button id="addVisitanteBtn" class="btn btn-primary">
                        <span class="btn-icon">➕</span>
                        Novo Visitante
                    </button>
                    <button id="exportVisitantesBtn" class="btn btn-outline">
                        <span class="btn-icon">📄</span>
                        Exportar CSV
                    </button>
                </div>
            </div>
            
            <div class="visitantes-content">
                <!-- Filters -->
                <div class="card filters-card">
                    <div class="filters-section">
                        <div class="filter-row">
                            <div class="form-group">
                                <label class="form-label">Buscar</label>
                                <input type="text" id="searchInput" class="form-input" 
                                       placeholder="Nome, documento ou placa">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Categoria</label>
                                <select id="categoriaFilter" class="form-select">
                                    <option value="">Todas</option>
                                    <option value="VISITANTE_COMUM">Visitante Comum</option>
                                    <option value="VISITANTE_ESPECIAL">Visitante Especial</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Status</label>
                                <select id="statusFilter" class="form-select">
                                    <option value="">Todos</option>
                                    <option value="true">Ativo</option>
                                    <option value="false">Inativo</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <button id="clearFiltersBtn" class="btn btn-outline">Limpar</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Visitors Table -->
                <div class="card table-card">
                    <div id="visitantesTable" class="table-container">
                        <!-- Table will be populated here -->
                    </div>
                </div>
            </div>
        </div>
    `;
}

export function mount() {
    const store = window.app.getStore();
    const ui = window.app.getUI();
    
    let currentVisitantes = store.getVisitantes();
    
    // Initialize
    renderVisitantesTable();
    setupEventListeners();
    
    // Subscribe to changes
    store.subscribe('visitantes', (visitantes) => {
        currentVisitantes = visitantes;
        renderVisitantesTable();
    });
    
    function setupEventListeners() {
        // Add visitante button
        document.getElementById('addVisitanteBtn').addEventListener('click', () => {
            showVisitanteModal();
        });
        
        // Export button
        document.getElementById('exportVisitantesBtn').addEventListener('click', () => {
            exportVisitantes();
        });
        
        // Filters
        document.getElementById('searchInput').addEventListener('input', renderVisitantesTable);
        document.getElementById('categoriaFilter').addEventListener('change', renderVisitantesTable);
        document.getElementById('statusFilter').addEventListener('change', renderVisitantesTable);
        
        // Clear filters
        document.getElementById('clearFiltersBtn').addEventListener('click', () => {
            document.getElementById('searchInput').value = '';
            document.getElementById('categoriaFilter').value = '';
            document.getElementById('statusFilter').value = '';
            renderVisitantesTable();
        });
    }
    
    function renderVisitantesTable() {
        const filteredVisitantes = applyFilters();
        const tableContainer = document.getElementById('visitantesTable');
        
        if (filteredVisitantes.length === 0) {
            tableContainer.innerHTML = '<p class="no-data">Nenhum visitante encontrado</p>';
            return;
        }
        
        const columns = [
            { key: 'nome', label: 'Nome', sortable: true },
            { key: 'documento', label: 'Documento', sortable: true },
            { key: 'placa', label: 'Placa', sortable: true, render: (value) => ui.formatPlaca(value) },
            { key: 'categoria', label: 'Categoria', sortable: true, render: (value) => getCategoriaTexto(value) },
            { key: 'empresa', label: 'Empresa', sortable: true },
            { key: 'contato', label: 'Contato', sortable: true },
            { 
                key: 'ativo', 
                label: 'Status', 
                render: (value) => value ? 
                    '<span class="badge badge-success">Ativo</span>' : 
                    '<span class="badge badge-error">Inativo</span>' 
            },
            { 
                key: 'criadoEm', 
                label: 'Criado em', 
                render: (value) => ui.formatDate(value) 
            },
            {
                key: 'actions',
                label: 'Ações',
                render: (_, visitante) => `
                    <div class="table-actions">
                        <button class="btn btn-sm btn-outline" onclick="editVisitante('${visitante.id}')">
                            ✏️ Editar
                        </button>
                        <button class="btn btn-sm btn-outline" onclick="toggleVisitanteStatus('${visitante.id}')">
                            ${visitante.ativo ? '🚫 Desativar' : '✅ Ativar'}
                        </button>
                        <button class="btn btn-sm btn-outline" onclick="deleteVisitante('${visitante.id}')">
                            🗑️ Excluir
                        </button>
                    </div>
                `
            }
        ];
        
        const table = ui.createTable(filteredVisitantes, columns, {
            className: 'visitantes-table',
            sortable: true,
            onRowClick: (visitante) => {
                showVisitanteDetails(visitante);
            }
        });
        
        tableContainer.innerHTML = '';
        tableContainer.appendChild(table);
        
        // Make action functions globally accessible
        window.editVisitante = editVisitante;
        window.toggleVisitanteStatus = toggleVisitanteStatus;
        window.deleteVisitante = deleteVisitante;
    }
    
    function applyFilters() {
        const search = document.getElementById('searchInput').value.toLowerCase();
        const categoria = document.getElementById('categoriaFilter').value;
        const status = document.getElementById('statusFilter').value;
        
        return currentVisitantes.filter(visitante => {
            // Search filter
            if (search && !visitante.nome.toLowerCase().includes(search) &&
                !visitante.documento.toLowerCase().includes(search) &&
                !visitante.placa.toLowerCase().includes(search)) {
                return false;
            }
            
            // Category filter
            if (categoria && visitante.categoria !== categoria) {
                return false;
            }
            
            // Status filter
            if (status !== '' && visitante.ativo.toString() !== status) {
                return false;
            }
            
            return true;
        });
    }
    
    function showVisitanteModal(visitante = null) {
        const isEdit = !!visitante;
        const title = isEdit ? 'Editar Visitante' : 'Novo Visitante';
        
        const formHTML = `
            <form id="visitanteForm">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Nome <span class="required">*</span></label>
                        <input type="text" name="nome" class="form-input" required
                               value="${visitante?.nome || ''}" placeholder="Nome completo">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Documento <span class="required">*</span></label>
                        <input type="text" name="documento" class="form-input" required
                               value="${visitante?.documento || ''}" placeholder="CPF ou RG">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Placa <span class="required">*</span></label>
                        <input type="text" name="placa" class="form-input" required
                               value="${visitante?.placa || ''}" placeholder="ABC-1234">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Categoria <span class="required">*</span></label>
                        <select name="categoria" class="form-select" required>
                            <option value="">Selecione</option>
                            <option value="VISITANTE_COMUM" ${visitante?.categoria === 'VISITANTE_COMUM' ? 'selected' : ''}>
                                Visitante Comum
                            </option>
                            <option value="VISITANTE_ESPECIAL" ${visitante?.categoria === 'VISITANTE_ESPECIAL' ? 'selected' : ''}>
                                Visitante Especial
                            </option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Empresa</label>
                        <input type="text" name="empresa" class="form-input"
                               value="${visitante?.empresa || ''}" placeholder="Nome da empresa">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Contato</label>
                        <input type="text" name="contato" class="form-input"
                               value="${visitante?.contato || ''}" placeholder="(11) 99999-9999">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Observações</label>
                    <textarea name="observacoes" class="form-textarea" rows="3"
                              placeholder="Informações adicionais">${visitante?.observacoes || ''}</textarea>
                </div>
                
                ${isEdit ? `
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select name="ativo" class="form-select">
                            <option value="true" ${visitante?.ativo ? 'selected' : ''}>Ativo</option>
                            <option value="false" ${!visitante?.ativo ? 'selected' : ''}>Inativo</option>
                        </select>
                    </div>
                ` : ''}
                
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" onclick="ui.closeModal(this.closest('.modal-overlay'))">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary">
                        ${isEdit ? 'Atualizar' : 'Criar'} Visitante
                    </button>
                </div>
            </form>
        `;
        
        const modal = ui.showModal(formHTML, { title, className: 'visitante-modal' });
        
        const form = modal.querySelector('#visitanteForm');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());
            
            // Validate plate
            if (!store.validarPlaca(data.placa)) {
                ui.showToast('Placa inválida', 'error');
                return;
            }
            
            // Convert ativo to boolean
            if (data.ativo !== undefined) {
                data.ativo = data.ativo === 'true';
            }
            
            if (isEdit) {
                store.updateVisitante(visitante.id, data);
                ui.showToast('Visitante atualizado com sucesso', 'success');
            } else {
                store.addVisitante(data);
                ui.showToast('Visitante criado com sucesso', 'success');
            }
            
            ui.closeModal(modal);
        });
    }
    
    function showVisitanteDetails(visitante) {
        const detailsHTML = `
            <div class="visitante-details">
                <div class="detail-section">
                    <h4>Informações Pessoais</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Nome:</span>
                            <span class="detail-value">${visitante.nome}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Documento:</span>
                            <span class="detail-value">${visitante.documento}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Contato:</span>
                            <span class="detail-value">${visitante.contato || 'Não informado'}</span>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h4>Informações do Veículo</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Placa:</span>
                            <span class="detail-value">${ui.formatPlaca(visitante.placa)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Categoria:</span>
                            <span class="detail-value">${getCategoriaTexto(visitante.categoria)}</span>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h4>Informações Empresariais</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Empresa:</span>
                            <span class="detail-value">${visitante.empresa || 'Não informado'}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Status:</span>
                            <span class="detail-value">
                                <span class="badge badge-${visitante.ativo ? 'success' : 'error'}">
                                    ${visitante.ativo ? 'Ativo' : 'Inativo'}
                                </span>
                            </span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Criado em:</span>
                            <span class="detail-value">${ui.formatDate(visitante.criadoEm)}</span>
                        </div>
                    </div>
                </div>
                
                ${visitante.observacoes ? `
                    <div class="detail-section">
                        <h4>Observações</h4>
                        <p class="observacoes-text">${visitante.observacoes}</p>
                    </div>
                ` : ''}
            </div>
        `;
        
        ui.showModal(detailsHTML, { 
            title: `Visitante: ${visitante.nome}`,
            className: 'visitante-details-modal'
        });
    }
    
    function editVisitante(id) {
        const visitante = currentVisitantes.find(v => v.id === id);
        if (visitante) {
            showVisitanteModal(visitante);
        }
    }
    
    function toggleVisitanteStatus(id) {
        const visitante = currentVisitantes.find(v => v.id === id);
        if (visitante) {
            store.updateVisitante(id, { ativo: !visitante.ativo });
            const status = visitante.ativo ? 'desativado' : 'ativado';
            ui.showToast(`Visitante ${status} com sucesso`, 'success');
        }
    }
    
    function deleteVisitante(id) {
        const visitante = currentVisitantes.find(v => v.id === id);
        if (visitante && confirm(`Deseja realmente excluir o visitante ${visitante.nome}?`)) {
            store.deleteVisitante(id);
            ui.showToast('Visitante excluído com sucesso', 'success');
        }
    }
    
    function exportVisitantes() {
        const filteredVisitantes = applyFilters();
        
        if (filteredVisitantes.length === 0) {
            ui.showToast('Nenhum visitante para exportar', 'warning');
            return;
        }
        
        const csvData = filteredVisitantes.map(v => ({
            Nome: v.nome,
            Documento: v.documento,
            Placa: v.placa,
            Categoria: getCategoriaTexto(v.categoria),
            Empresa: v.empresa || '',
            Contato: v.contato || '',
            Status: v.ativo ? 'Ativo' : 'Inativo',
            'Criado em': ui.formatDate(v.criadoEm),
            Observações: v.observacoes || ''
        }));
        
        const filename = `visitantes_${new Date().toISOString().split('T')[0]}.csv`;
        ui.downloadCSV(csvData, filename);
        ui.showToast('Arquivo CSV exportado com sucesso', 'success');
    }
    
    function getCategoriaTexto(categoria) {
        const categorias = {
            'VISITANTE_COMUM': 'Visitante Comum',
            'VISITANTE_ESPECIAL': 'Visitante Especial'
        };
        return categorias[categoria] || categoria;
    }
}