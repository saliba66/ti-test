// ARQUIVO: Código/js/pages/ia-monitoramento.js

/**
 * Renderiza o conteúdo HTML para a página de Monitoramento IA.
 * Versão estética com o título "Teste IA".
 */
export function render() {
    return `
        <div class="page-container">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Teste IA</h2>
                </div>
                
                <div class="cancela-layout" style="grid-template-columns: 1fr 1fr; gap: 3rem;">

                    <div style="text-align: center;">
                        <h3 class="card-title" style="margin-bottom: 1.5rem;">Placa (Dado a ser Processado)</h3>
                        
                        <div id="placa-representacao" style="
                            background-color: var(--color-white); /* Fundo branco */
                            color: var(--color-gray-900); /* Texto preto */
                            border: 3px solid var(--color-gray-900);
                            border-radius: 6px;
                            padding: 15px 30px;
                            width: 80%;
                            max-width: 300px; 
                            margin: 0 auto 2.5rem; 
                            font-family: 'Consolas', monospace;
                            font-size: 2rem;
                            font-weight: 700;
                            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                        ">
                            ABC-1234
                        </div>

                        <button id="simularEnvioBtn" class="btn btn-primary" style="width: 100%; max-width: 320px; font-size: 1rem;" disabled>
                            Enviar Dados para Simulação
                        </button>
                        
                        <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 1rem;">O botão é desabilitado, pois é apenas um elemento estético de envio.</p>
                    </div>

                    <div style="text-align: center;">
                        <h3 class="card-title" style="margin-bottom: 1.5rem;">Status do Sistema Físico</h3>

                        <div id="resultado-cancela" class="result-success" style="padding: 2rem; min-height: 250px; background-color: var(--bg-card); border: 2px solid var(--status-success); border-radius: 0.5rem; box-shadow: 0 0 10px rgba(16, 185, 129, 0.3);">
                            
                            <div class="result-icon" style="color: var(--status-success);">✅</div>
                            <h4 style="font-size: 1.5rem; color: var(--status-success); margin-bottom: 0.5rem;">CANCELA ABERTA</h4>
                            <p style="color: var(--text-secondary);">Comando de liberação enviado com sucesso.</p>
                        </div>
                        
                        <div style="margin-top: 1.5rem; text-align: left; padding: 0 1rem;">
                            <div class="status-item" style="border-bottom: 1px dashed var(--border-color);">
                                <span class="status-label">Resultado Final:</span>
                                <span class="status-value" style="color: var(--status-success);">ACESSO LIBERADO</span>
                            </div>
                            <div class="status-item">
                                <span class="status-label">Tipo de Usuário:</span>
                                <span class="status-value">Aluno</span>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Função de montagem vazia, mantida para evitar erros de roteamento.
 */
export function mount() {
    console.log('Página Monitoramento IA carregada em modo de apresentação estética.');
}