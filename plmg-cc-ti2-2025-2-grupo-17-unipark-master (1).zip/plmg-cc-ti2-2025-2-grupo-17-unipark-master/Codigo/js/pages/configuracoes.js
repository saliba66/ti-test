// Settings page - system configuration and preferences
export function render() {
    return `
        <div class="configuracoes-container">
            <div class="page-header">
                <h1>Configurações</h1>
                <p class="page-description">Preferências do sistema e parâmetros de funcionamento</p>
            </div>
            
            <div class="configuracoes-content">
                <!-- UI Preferences -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Preferências de Interface</h3>
                        <p class="card-description">Configurações de aparência e comportamento</p>
                    </div>
                    <div class="config-section">
                        <div class="config-item">
                            <div class="config-info">
                                <h4>Tema</h4>
                                <p>Escolha entre tema claro ou escuro</p>
                            </div>
                            <div class="config-control">
                                <label class="switch">
                                    <input type="checkbox" id="darkModeToggle">
                                    <span class="slider"></span>
                                </label>
                                <span id="themeLabel">Claro</span>
                            </div>
                        </div>
                        
                        <div class="config-item">
                            <div class="config-info">
                                <h4>Persistência de Dados</h4>
                                <p>Salvar dados automaticamente no navegador</p>
                            </div>
                            <div class="config-control">
                                <label class="switch">
                                    <input type="checkbox" id="persistToggle">
                                    <span class="slider"></span>
                                </label>
                                <span id="persistLabel">Desabilitado</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Business Rules -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Regras de Negócio</h3>
                        <p class="card-description">Parâmetros operacionais do estacionamento</p>
                    </div>
                    <div class="config-section">
                        <div class="config-item">
                            <div class="config-info">
                                <h4>Tempo Máximo de Ocupação</h4>
                                <p>Configurar limites de tempo por categoria</p>
                            </div>
                            <div class="config-control">
                                <button id="editTimeoutsBtn" class="btn btn-outline">
                                    ⚙️ Configurar
                                </button>
                            </div>
                        </div>
                        
                        <div class="config-item">
                            <div class="config-info">
                                <h4>Distribuição de Vagas</h4>
                                <p>Percentual de vagas por tipo</p>
                            </div>
                            <div class="config-control">
                                <button id="editDistributionBtn" class="btn btn-outline">
                                    ⚙️ Configurar
                                </button>
                            </div>
                        </div>
                        
                        <div class="config-item">
                            <div class="config-info">
                                <h4>Janela de Tolerância</h4>
                                <p>Tempo adicional antes de considerar vaga vencida</p>
                            </div>
                            <div class="config-control">
                                <input type="number" id="toleranceInput" class="form-input" 
                                       min="0" max="120" value="30" style="width: 80px;">
                                <span>minutos</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Data Management -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Gerenciamento de Dados</h3>
                        <p class="card-description">Backup, importação e limpeza de dados</p>
                    </div>
                    <div class="config-section">
                        <div class="config-item">
                            <div class="config-info">
                                <h4>Backup dos Dados</h4>
                                <p>Exportar todos os dados do sistema</p>
                            </div>
                            <div class="config-control">
                                <button id="exportDataBtn" class="btn btn-secondary">
                                    📁 Fazer Backup
                                </button>
                            </div>
                        </div>
                        
                        <div class="config-item">
                            <div class="config-info">
                                <h4>Importar Dados</h4>
                                <p>Restaurar dados de um backup anterior</p>
                            </div>
                            <div class="config-control">
                                <button id="importDataBtn" class="btn btn-secondary">
                                    📂 Importar Backup
                                </button>
                            </div>
                        </div>
                        
                        <div class="config-item">
                            <div class="config-info">
                                <h4>Limpar Eventos Antigos</h4>
                                <p>Remover histórico de movimentação mais antigo que</p>
                            </div>
                            <div class="config-control">
                                <select id="cleanupPeriod" class="form-select" style="width: 120px;">
                                    <option value="7">7 dias</option>
                                    <option value="30" selected>30 dias</option>
                                    <option value="90">90 dias</option>
                                    <option value="365">1 ano</option>
                                </select>
                                <button id="cleanupBtn" class="btn btn-outline">
                                    🗑️ Limpar
                                </button>
                            </div>
                        </div>
                        
                        <div class="config-item danger">
                            <div class="config-info">
                                <h4>Resetar Sistema</h4>
                                <p class="danger-text">⚠️ Remove todos os dados e reinicia com dados iniciais</p>
                            </div>
                            <div class="config-control">
                                <button id="resetSystemBtn" class="btn btn-error">
                                    🔄 Resetar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- System Info -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Informações do Sistema</h3>
                        <p class="card-description">Detalhes sobre o estado atual do sistema</p>
                    </div>
                    <div class="info-section">
                        <div class="info-grid">
                            <div class="info-item">
                                <span class="info-label">Versão:</span>
                                <span class="info-value">Unipark v1.0.0</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total de Usuários:</span>
                                <span id="totalUsuarios" class="info-value">0</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total de Visitantes:</span>
                                <span id="totalVisitantes" class="info-value">0</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total de Vagas:</span>
                                <span id="totalVagas" class="info-value">0</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total de Eventos:</span>
                                <span id="totalEventos" class="info-value">0</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Dados Persistidos:</span>
                                <span id="dataPersisted" class="info-value">-</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Hidden file input -->
        <input type="file" id="backupFileInput" accept=".json" style="display: none;">
    `;
}

export function mount() {
    const store = window.app.getStore();
    const ui = window.app.getUI();
    
    // Initialize
    loadCurrentSettings();
    updateSystemInfo();
    setupEventListeners();
    
    // Subscribe to preference changes
    store.subscribe('prefs', loadCurrentSettings);
    
    function setupEventListeners() {
        // Theme toggle
        document.getElementById('darkModeToggle').addEventListener('change', (e) => {
            const isDark = e.target.checked;
            store.updatePreferences({ darkMode: isDark });
            
            // Update theme
            const html = document.documentElement;
            if (isDark) {
                html.classList.add('dark');
            } else {
                html.classList.remove('dark');
            }
            
            document.getElementById('themeLabel').textContent = isDark ? 'Escuro' : 'Claro';
            ui.showToast(`Tema ${isDark ? 'escuro' : 'claro'} ativado`, 'success');
        });
        
        // Persistence toggle
        document.getElementById('persistToggle').addEventListener('change', (e) => {
            const persist = e.target.checked;
            store.updatePreferences({ persist });
            
            document.getElementById('persistLabel').textContent = persist ? 'Habilitado' : 'Desabilitado';
            
            if (persist) {
                ui.showToast('Dados serão salvos automaticamente', 'success');
            } else {
                ui.showToast('Persistência desabilitada', 'warning');
            }
        });
        
        // Business rule buttons
        document.getElementById('editTimeoutsBtn').addEventListener('click', showTimeoutConfig);
        document.getElementById('editDistributionBtn').addEventListener('click', showDistributionConfig);
        
        // Tolerance input
        document.getElementById('toleranceInput').addEventListener('change', (e) => {
            const tolerance = parseInt(e.target.value);
            // Store tolerance setting (would need to add to store structure)
            ui.showToast(`Tolerância atualizada para ${tolerance} minutos`, 'success');
        });
        
        // Data management buttons
        document.getElementById('exportDataBtn').addEventListener('click', exportAllData);
        document.getElementById('importDataBtn').addEventListener('click', () => {
            document.getElementById('backupFileInput').click();
        });
        document.getElementById('cleanupBtn').addEventListener('click', cleanupOldEvents);
        document.getElementById('resetSystemBtn').addEventListener('click', resetSystem);
        
        // File input
        document.getElementById('backupFileInput').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                importData(file);
            }
        });
    }
    
    function loadCurrentSettings() {
        const prefs = store.getPreferences();
        
        // Update UI controls
        document.getElementById('darkModeToggle').checked = prefs.darkMode;
        document.getElementById('themeLabel').textContent = prefs.darkMode ? 'Escuro' : 'Claro';
        
        document.getElementById('persistToggle').checked = prefs.persist;
        document.getElementById('persistLabel').textContent = prefs.persist ? 'Habilitado' : 'Desabilitado';
    }
    
    function updateSystemInfo() {
        const usuarios = store.getUsuarios();
        const visitantes = store.getVisitantes();
        const vagas = store.getVagas();
        const eventos = store.getEventos();
        const prefs = store.getPreferences();
        
        document.getElementById('totalUsuarios').textContent = usuarios.length;
        document.getElementById('totalVisitantes').textContent = visitantes.length;
        document.getElementById('totalVagas').textContent = vagas.length;
        document.getElementById('totalEventos').textContent = eventos.length;
        document.getElementById('dataPersisted').textContent = prefs.persist ? 'Sim' : 'Não';
    }
    
    function showTimeoutConfig() {
        const timeouts = {
            'FUNCIONARIO': 8,
            'PCD': 8,
            'VISITANTE_ESPECIAL': 4,
            'ALUNO': 4,
            'VISITANTE_COMUM': 2
        };
        
        const formHTML = `
            <form id="timeoutForm">
                <div class="timeout-config">
                    <div class="form-group">
                        <label class="form-label">Funcionário (horas)</label>
                        <input type="number" name="FUNCIONARIO" class="form-input" min="1" max="24" value="${timeouts.FUNCIONARIO}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">PCD (horas)</label>
                        <input type="number" name="PCD" class="form-input" min="1" max="24" value="${timeouts.PCD}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Visitante Especial (horas)</label>
                        <input type="number" name="VISITANTE_ESPECIAL" class="form-input" min="1" max="12" value="${timeouts.VISITANTE_ESPECIAL}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Aluno (horas)</label>
                        <input type="number" name="ALUNO" class="form-input" min="1" max="12" value="${timeouts.ALUNO}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Visitante Comum (horas)</label>
                        <input type="number" name="VISITANTE_COMUM" class="form-input" min="1" max="8" value="${timeouts.VISITANTE_COMUM}">
                    </div>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" onclick="ui.closeModal(this.closest('.modal-overlay'))">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary">
                        Salvar Configurações
                    </button>
                </div>
            </form>
        `;
        
        const modal = ui.showModal(formHTML, {
            title: 'Configurar Tempo Máximo de Ocupação',
            className: 'timeout-config-modal'
        });
        
        const form = modal.querySelector('#timeoutForm');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            ui.showToast('Configurações de tempo salvas', 'success');
            ui.closeModal(modal);
        });
    }
    
    function showDistributionConfig() {
        const distribution = {
            'COMUM': 70,
            'FUNCIONARIO': 15,
            'PCD': 10,
            'VISITANTE_ESPECIAL': 5
        };
        
        const formHTML = `
            <form id="distributionForm">
                <div class="distribution-config">
                    <p class="config-note">Configure o percentual de vagas por tipo (total deve somar 100%)</p>
                    
                    <div class="form-group">
                        <label class="form-label">Vagas Comuns (%)</label>
                        <input type="number" name="COMUM" class="form-input" min="0" max="100" value="${distribution.COMUM}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Vagas de Funcionário (%)</label>
                        <input type="number" name="FUNCIONARIO" class="form-input" min="0" max="100" value="${distribution.FUNCIONARIO}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Vagas PCD (%)</label>
                        <input type="number" name="PCD" class="form-input" min="0" max="100" value="${distribution.PCD}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Vagas Visitante Especial (%)</label>
                        <input type="number" name="VISITANTE_ESPECIAL" class="form-input" min="0" max="100" value="${distribution.VISITANTE_ESPECIAL}">
                    </div>
                    
                    <div class="total-display">
                        Total: <span id="totalPercentage">100</span>%
                    </div>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" onclick="ui.closeModal(this.closest('.modal-overlay'))">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary">
                        Salvar Distribuição
                    </button>
                </div>
            </form>
        `;
        
        const modal = ui.showModal(formHTML, {
            title: 'Configurar Distribuição de Vagas',
            className: 'distribution-config-modal'
        });
        
        // Update total on input change
        const inputs = modal.querySelectorAll('input[type="number"]');
        inputs.forEach(input => {
            input.addEventListener('input', () => {
                const total = Array.from(inputs).reduce((sum, inp) => sum + parseInt(inp.value || 0), 0);
                document.getElementById('totalPercentage').textContent = total;
            });
        });
        
        const form = modal.querySelector('#distributionForm');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const total = Array.from(inputs).reduce((sum, inp) => sum + parseInt(inp.value || 0), 0);
            
            if (total !== 100) {
                ui.showToast('O total deve somar exatamente 100%', 'error');
                return;
            }
            
            ui.showToast('Distribuição de vagas salva', 'success');
            ui.closeModal(modal);
        });
    }
    
    function exportAllData() {
        const data = {
            version: '1.0.0',
            timestamp: Date.now(),
            data: store.getState()
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        
        link.href = url;
        link.download = `unipark_backup_${new Date().toISOString().split('T')[0]}.json`;
        link.click();
        
        URL.revokeObjectURL(url);
        ui.showToast('Backup exportado com sucesso', 'success');
    }
    
    function importData(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const backup = JSON.parse(e.target.result);
                
                if (!backup.data) {
                    throw new Error('Formato de backup inválido');
                }
                
                if (confirm('Esta ação irá substituir todos os dados atuais. Deseja continuar?')) {
                    // Restore data
                    store.setUsuarios(backup.data.usuarios || []);
                    store.setVisitantes(backup.data.visitantes || []);
                    store.setVagas(backup.data.vagas || []);
                    store.setEventos(backup.data.eventos || []);
                    
                    updateSystemInfo();
                    ui.showToast('Dados importados com sucesso', 'success');
                }
            } catch (error) {
                ui.showToast('Erro ao importar dados', 'error');
            }
        };
        
        reader.readAsText(file);
    }
    
    function cleanupOldEvents() {
        const period = parseInt(document.getElementById('cleanupPeriod').value);
        const cutoffDate = Date.now() - (period * 24 * 60 * 60 * 1000);
        
        const eventos = store.getEventos();
        const oldCount = eventos.length;
        const filteredEventos = eventos.filter(e => e.timestamp > cutoffDate);
        
        store.setEventos(filteredEventos);
        
        const removed = oldCount - filteredEventos.length;
        ui.showToast(`${removed} eventos antigos removidos`, 'success');
        updateSystemInfo();
    }
    
    function resetSystem() {
        const confirmText = 'RESETAR';
        const userInput = prompt(`Esta ação irá REMOVER TODOS OS DADOS do sistema.\n\nPara confirmar, digite "${confirmText}" (em maiúsculas):`);
        
        if (userInput === confirmText) {
            // Clear storage
            store.clearStorage();
            
            // Reload with seed data
            import('../data/seed.js').then(({ seedData }) => {
                seedData(store);
                updateSystemInfo();
                ui.showToast('Sistema resetado com dados iniciais', 'success');
            });
        }
    }
}