// 404 Not Found page
export function render() {
    return `
        <div class="notfound-container">
            <div class="notfound-content">
                <div class="notfound-icon">🚧</div>
                <h1 class="notfound-title">Página não encontrada</h1>
                <p class="notfound-description">
                    A página que você está procurando não existe ou foi movida.
                </p>
                <div class="notfound-actions">
                    <a href="#/dashboard" class="btn btn-primary">
                        <span class="btn-icon">🏠</span>
                        Voltar ao Dashboard
                    </a>
                    <button onclick="history.back()" class="btn btn-outline">
                        <span class="btn-icon">⬅️</span>
                        Página Anterior
                    </button>
                </div>
            </div>
        </div>
    `;
}

export function mount() {
    // No special mounting logic needed for 404 page
    console.log('404 page mounted');
}