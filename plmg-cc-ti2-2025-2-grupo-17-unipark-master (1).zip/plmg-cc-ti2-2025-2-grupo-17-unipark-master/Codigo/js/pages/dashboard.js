// Dashboard page - overview with KPIs and recent activity
export function render() {
    return `
        <div class="dashboard-container">
            <div class="page-header">
                <h1>Dashboard</h1>
                <p class="page-description">Visão geral do estacionamento</p>
            </div>
            
            <div class="dashboard-grid">
                <!-- KPI Cards -->
                <div class="kpi-section">
                    <h2>Estatísticas</h2>
                    <div class="grid grid-cols-4" id="kpiCards">
                        <!-- KPI cards will be populated here -->
                    </div>
                </div>
                
                <!-- Chart Section -->
                <div class="chart-section">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Ocupação por Hora</h3>
                            <p class="card-description">Últimas 12 horas</p>
                        </div>
                        <div id="occupancyChart" class="chart-container">
                            <!-- Chart will be generated here -->
                        </div>
                    </div>
                </div>
                
                <!-- Recent Activity -->
                <div class="activity-section">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Atividade Recente</h3>
                            <p class="card-description">Últimas 10 movimentações</p>
                        </div>
                        <div id="recentActivity" class="activity-list">
                            <!-- Activity items will be populated here -->
                        </div>
                    </div>
                </div>
                
                <!-- Alerts Section -->
                <div class="alerts-section">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Alertas</h3>
                            <p class="card-description">Situações que requerem atenção</p>
                        </div>
                        <div id="alertsList" class="alerts-list">
                            <!-- Alerts will be populated here -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

export function mount() {
    const store = window.app.getStore();
    const ui = window.app.getUI();
    
    // Load data and populate components
    populateKPICards(store, ui);
    populateOccupancyChart(store);
    populateRecentActivity(store, ui);
    populateAlerts(store, ui);
    
    // Subscribe to data changes
    store.subscribe('vagas', () => {
        populateKPICards(store, ui);
        populateOccupancyChart(store);
    });
    
    store.subscribe('eventos', () => {
        populateRecentActivity(store, ui);
        populateAlerts(store, ui);
    });
}

function populateKPICards(store, ui) {
    const vagas = store.getVagas();
    const eventos = store.getEventos();
    
    const stats = calculateStats(vagas, eventos);
    const kpiContainer = document.getElementById('kpiCards');
    
    if (!kpiContainer) return;
    
    kpiContainer.innerHTML = `
        <div class="kpi-card">
            <div class="kpi-header">
                <span class="kpi-icon">🅿️</span>
                <span class="kpi-label">Total de Vagas</span>
            </div>
            <div class="kpi-value">${stats.totalVagas}</div>
        </div>
        
        <div class="kpi-card occupied">
            <div class="kpi-header">
                <span class="kpi-icon">🚗</span>
                <span class="kpi-label">Ocupadas</span>
            </div>
            <div class="kpi-value">${stats.vagasOcupadas}</div>
            <div class="kpi-percentage">${stats.percentualOcupacao}%</div>
        </div>
        
        <div class="kpi-card available">
            <div class="kpi-header">
                <span class="kpi-icon">✅</span>
                <span class="kpi-label">Disponíveis</span>
            </div>
            <div class="kpi-value">${stats.vagasLivres}</div>
        </div>
        
        <div class="kpi-card special">
            <div class="kpi-header">
                <span class="kpi-icon">⭐</span>
                <span class="kpi-label">Especiais</span>
            </div>
            <div class="kpi-value">${stats.vagasEspeciais}</div>
            <div class="kpi-sublabel">PCD, Funcionário, VIP</div>
        </div>
    `;
}

function populateOccupancyChart(store) {
    const eventos = store.getEventos();
    const chartContainer = document.getElementById('occupancyChart');
    
    if (!chartContainer) return;
    
    const chartData = generateHourlyOccupancyData(eventos);
    const svgChart = createOccupancyChart(chartData);
    
    chartContainer.innerHTML = svgChart;
}

function populateRecentActivity(store, ui) {
    const eventos = store.getEventos();
    const vagas = store.getVagas();
    const activityContainer = document.getElementById('recentActivity');
    
    if (!activityContainer) return;
    
    // Get last 10 events, sorted by timestamp descending
    const recentEvents = eventos
        .sort((a, b) => b.timestamp - a.timestamp)
        .slice(0, 10);
    
    if (recentEvents.length === 0) {
        activityContainer.innerHTML = '<p class="no-data">Nenhuma atividade recente</p>';
        return;
    }
    
    const activityHTML = recentEvents.map(evento => {
        const vaga = vagas.find(v => v.id === evento.vagaId);
        const vagaInfo = vaga ? ` - Vaga ${vaga.numero}` : '';
        const timeAgo = getTimeAgo(evento.timestamp);
        
        return `
            <div class="activity-item">
                <div class="activity-icon ${evento.decisao.toLowerCase()}">
                    ${getEventIcon(evento.decisao)}
                </div>
                <div class="activity-content">
                    <div class="activity-main">
                        <span class="activity-placa">${ui.formatPlaca(evento.placa)}</span>
                        <span class="activity-status badge badge-${getEventBadgeType(evento.decisao)}">
                            ${evento.decisao}
                        </span>
                    </div>
                    <div class="activity-details">
                        ${evento.motivo}${vagaInfo}
                    </div>
                    <div class="activity-time">${timeAgo}</div>
                </div>
            </div>
        `;
    }).join('');
    
    activityContainer.innerHTML = activityHTML;
}

function populateAlerts(store, ui) {
    const vagas = store.getVagas();
    const eventos = store.getEventos();
    const alertsContainer = document.getElementById('alertsList');
    
    if (!alertsContainer) return;
    
    const alerts = generateAlerts(vagas, eventos);
    
    if (alerts.length === 0) {
        alertsContainer.innerHTML = '<p class="no-data">Nenhum alerta no momento</p>';
        return;
    }
    
    const alertsHTML = alerts.map(alert => `
        <div class="alert-item ${alert.type}">
            <div class="alert-icon">${alert.icon}</div>
            <div class="alert-content">
                <div class="alert-title">${alert.title}</div>
                <div class="alert-description">${alert.description}</div>
            </div>
            <div class="alert-time">${getTimeAgo(alert.timestamp)}</div>
        </div>
    `).join('');
    
    alertsContainer.innerHTML = alertsHTML;
}

function calculateStats(vagas, eventos) {
    const totalVagas = vagas.length;
    const vagasOcupadas = vagas.filter(v => v.status === 'OCUPADA').length;
    const vagasLivres = vagas.filter(v => v.status === 'LIVRE').length;
    const vagasEspeciais = vagas.filter(v => 
        ['PCD', 'FUNCIONARIO', 'VISITANTE_ESPECIAL'].includes(v.tipo)
    ).length;
    const percentualOcupacao = totalVagas > 0 ? 
        Math.round((vagasOcupadas / totalVagas) * 100) : 0;
    
    return {
        totalVagas,
        vagasOcupadas,
        vagasLivres,
        vagasEspeciais,
        percentualOcupacao
    };
}

function generateHourlyOccupancyData(eventos) {
    const now = Date.now();
    const hourlyData = [];
    
    // Generate data for last 12 hours
    for (let i = 11; i >= 0; i--) {
        const hourStart = now - (i * 60 * 60 * 1000);
        const hourEnd = hourStart + (60 * 60 * 1000);
        
        const hourEvents = eventos.filter(e => 
            e.timestamp >= hourStart && e.timestamp < hourEnd && e.decisao === 'AUTORIZADO'
        );
        
        hourlyData.push({
            hour: new Date(hourStart).getHours(),
            entries: hourEvents.length,
            timestamp: hourStart
        });
    }
    
    return hourlyData;
}

function createOccupancyChart(data) {
    const width = 400;
    const height = 200;
    const margin = { top: 20, right: 20, bottom: 40, left: 40 };
    const chartWidth = width - margin.left - margin.right;
    const chartHeight = height - margin.top - margin.bottom;
    
    const maxEntries = Math.max(...data.map(d => d.entries), 1);
    
    const bars = data.map((d, i) => {
        const x = margin.left + (i * (chartWidth / data.length));
        const barWidth = chartWidth / data.length - 2;
        const barHeight = (d.entries / maxEntries) * chartHeight;
        const y = margin.top + chartHeight - barHeight;
        
        return `
            <rect x="${x}" y="${y}" width="${barWidth}" height="${barHeight}" 
                  fill="var(--color-blue)" opacity="0.8" rx="2"/>
            <text x="${x + barWidth/2}" y="${height - 5}" 
                  text-anchor="middle" font-size="10" fill="var(--text-muted)">
                ${d.hour}h
            </text>
            <text x="${x + barWidth/2}" y="${y - 5}" 
                  text-anchor="middle" font-size="10" fill="var(--text-secondary)">
                ${d.entries}
            </text>
        `;
    }).join('');
    
    return `
        <svg width="${width}" height="${height}" style="max-width: 100%; height: auto;">
            <defs>
                <style>
                    .chart-grid { stroke: var(--border-color); stroke-width: 1; opacity: 0.3; }
                    .chart-axis { stroke: var(--text-muted); stroke-width: 1; }
                </style>
            </defs>
            
            <!-- Grid lines -->
            ${Array.from({length: 5}, (_, i) => {
                const y = margin.top + (i * chartHeight / 4);
                return `<line x1="${margin.left}" y1="${y}" x2="${width - margin.right}" y2="${y}" class="chart-grid"/>`;
            }).join('')}
            
            <!-- Axes -->
            <line x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${height - margin.bottom}" class="chart-axis"/>
            <line x1="${margin.left}" y1="${height - margin.bottom}" x2="${width - margin.right}" y2="${height - margin.bottom}" class="chart-axis"/>
            
            <!-- Bars -->
            ${bars}
            
            <!-- Labels -->
            <text x="${width/2}" y="${height - 5}" text-anchor="middle" font-size="12" fill="var(--text-secondary)">Hora</text>
            <text x="15" y="${height/2}" text-anchor="middle" font-size="12" fill="var(--text-secondary)" transform="rotate(-90, 15, ${height/2})">Entradas</text>
        </svg>
    `;
}

function generateAlerts(vagas, eventos) {
    const alerts = [];
    const now = Date.now();
    
    // Check for long-occupied spots
    vagas.forEach(vaga => {
        if (vaga.status === 'OCUPADA' && vaga.desde) {
            const ocupadaHa = now - vaga.desde;
            const hours = Math.floor(ocupadaHa / (60 * 60 * 1000));
            
            if (hours >= 8) {
                alerts.push({
                    type: 'warning',
                    icon: '⚠️',
                    title: 'Vaga ocupada há muito tempo',
                    description: `Vaga ${vaga.numero} ocupada há ${hours} horas (${vaga.placaAtual})`,
                    timestamp: vaga.desde
                });
            }
        }
    });
    
    // Check for recent denied entries
    const recentDenied = eventos.filter(e => 
        e.decisao === 'NEGADO' && (now - e.timestamp) < (60 * 60 * 1000) // Last hour
    );
    
    if (recentDenied.length >= 3) {
        alerts.push({
            type: 'error',
            icon: '🚫',
            title: 'Muitas entradas negadas',
            description: `${recentDenied.length} tentativas negadas na última hora`,
            timestamp: now
        });
    }
    
    // Check for blocked spots
    const blockedSpots = vagas.filter(v => v.status === 'BLOQUEADA');
    if (blockedSpots.length > 0) {
        alerts.push({
            type: 'info',
            icon: 'ℹ️',
            title: 'Vagas bloqueadas',
            description: `${blockedSpots.length} vaga(s) bloqueada(s): ${blockedSpots.map(v => v.numero).join(', ')}`,
            timestamp: now
        });
    }
    
    return alerts.sort((a, b) => b.timestamp - a.timestamp);
}

function getEventIcon(decisao) {
    const icons = {
        'AUTORIZADO': '✅',
        'NEGADO': '❌',
        'MANUAL': '🔧'
    };
    return icons[decisao] || '📋';
}

function getEventBadgeType(decisao) {
    const types = {
        'AUTORIZADO': 'success',
        'NEGADO': 'error',
        'MANUAL': 'warning'
    };
    return types[decisao] || 'info';
}

function getTimeAgo(timestamp) {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / (60 * 1000));
    const hours = Math.floor(diff / (60 * 60 * 1000));
    const days = Math.floor(diff / (24 * 60 * 60 * 1000));
    
    if (minutes < 1) return 'agora';
    if (minutes < 60) return `${minutes}m atrás`;
    if (hours < 24) return `${hours}h atrás`;
    return `${days}d atrás`;
}