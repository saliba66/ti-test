// Movement history page - view and filter parking events
export function render() {
    return `
        <div class="movimentacao-container">
            <div class="page-header">
                <div class="header-content">
                    <h1>Movimentação</h1>
                    <p class="page-description">Histórico de entrada e saída de veículos</p>
                </div>
                <div class="header-actions">
                    <button id="exportMovimentacaoBtn" class="btn btn-primary">
                        <span class="btn-icon">📄</span>
                        Exportar CSV
                    </button>
                </div>
            </div>
            
            <div class="movimentacao-content">
                <!-- Summary Cards -->
                <div class="movimentacao-summary">
                    <div class="summary-card success">
                        <div class="summary-icon">✅</div>
                        <div class="summary-info">
                            <span class="summary-value" id="autorizadosCount">0</span>
                            <span class="summary-label">Autorizados</span>
                        </div>
                    </div>
                    <div class="summary-card error">
                        <div class="summary-icon">❌</div>
                        <div class="summary-info">
                            <span class="summary-value" id="negadosCount">0</span>
                            <span class="summary-label">Negados</span>
                        </div>
                    </div>
                    <div class="summary-card warning">
                        <div class="summary-icon">🔧</div>
                        <div class="summary-info">
                            <span class="summary-value" id="manuaisCount">0</span>
                            <span class="summary-label">Manuais</span>
                        </div>
                    </div>
                    <div class="summary-card info">
                        <div class="summary-icon">📊</div>
                        <div class="summary-info">
                            <span class="summary-value" id="totalCount">0</span>
                            <span class="summary-label">Total</span>
                        </div>
                    </div>
                </div>
                
                <!-- Filters -->
                <div class="card filters-card">
                    <div class="filters-section">
                        <div class="filter-row">
                            <div class="form-group">
                                <label class="form-label">Buscar</label>
                                <input type="text" id="searchInput" class="form-input" 
                                       placeholder="Placa do veículo">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Decisão</label>
                                <select id="decisaoFilter" class="form-select">
                                    <option value="">Todas</option>
                                    <option value="AUTORIZADO">Autorizado</option>
                                    <option value="NEGADO">Negado</option>
                                    <option value="MANUAL">Manual</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Categoria</label>
                                <select id="categoriaFilter" class="form-select">
                                    <option value="">Todas</option>
                                    <option value="ALUNO">Aluno</option>
                                    <option value="FUNCIONARIO">Funcionário</option>
                                    <option value="PCD">PCD</option>
                                    <option value="VISITANTE_COMUM">Visitante Comum</option>
                                    <option value="VISITANTE_ESPECIAL">Visitante Especial</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Período</label>
                                <select id="periodoFilter" class="form-select">
                                    <option value="">Todos</option>
                                    <option value="hoje">Hoje</option>
                                    <option value="ontem">Ontem</option>
                                    <option value="semana">Esta semana</option>
                                    <option value="mes">Este mês</option>
                                    <option value="personalizado">Personalizado</option>
                                </select>
                            </div>
                            <div class="form-group" id="customDateRange" style="display: none;">
                                <label class="form-label">Data Início</label>
                                <input type="date" id="dataInicio" class="form-input">
                                <label class="form-label">Data Fim</label>
                                <input type="date" id="dataFim" class="form-input">
                            </div>
                            <div class="form-group">
                                <button id="clearFiltersBtn" class="btn btn-outline">Limpar</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Events Timeline -->
                <div class="card timeline-card">
                    <div class="card-header">
                        <h3 class="card-title">Linha do Tempo</h3>
                        <div class="timeline-controls">
                            <button id="timelineViewBtn" class="btn btn-sm btn-outline active">
                                📅 Timeline
                            </button>
                            <button id="tableViewBtn" class="btn btn-sm btn-outline">
                                📋 Tabela
                            </button>
                        </div>
                    </div>
                    
                    <div id="timelineView" class="timeline-view">
                        <div id="eventsTimeline" class="events-timeline">
                            <!-- Timeline items will be populated here -->
                        </div>
                    </div>
                    
                    <div id="tableView" class="table-view hidden">
                        <div id="eventsTable" class="table-container">
                            <!-- Table will be populated here -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

export function mount() {
    const store = window.app.getStore();
    const ui = window.app.getUI();
    
    let currentEventos = store.getEventos();
    let isTimelineView = true;
    
    // Initialize
    renderMovimentacao();
    updateSummary();
    setupEventListeners();
    
    // Subscribe to changes
    store.subscribe('eventos', (eventos) => {
        currentEventos = eventos;
        renderMovimentacao();
        updateSummary();
    });
    
    function setupEventListeners() {
        // Export button
        document.getElementById('exportMovimentacaoBtn').addEventListener('click', exportMovimentacao);
        
        // Filters
        document.getElementById('searchInput').addEventListener('input', renderMovimentacao);
        document.getElementById('decisaoFilter').addEventListener('change', renderMovimentacao);
        document.getElementById('categoriaFilter').addEventListener('change', renderMovimentacao);
        document.getElementById('periodoFilter').addEventListener('change', (e) => {
            const customRange = document.getElementById('customDateRange');
            if (e.target.value === 'personalizado') {
                customRange.style.display = 'block';
            } else {
                customRange.style.display = 'none';
            }
            renderMovimentacao();
        });
        
        document.getElementById('dataInicio').addEventListener('change', renderMovimentacao);
        document.getElementById('dataFim').addEventListener('change', renderMovimentacao);
        
        // Clear filters
        document.getElementById('clearFiltersBtn').addEventListener('click', () => {
            document.getElementById('searchInput').value = '';
            document.getElementById('decisaoFilter').value = '';
            document.getElementById('categoriaFilter').value = '';
            document.getElementById('periodoFilter').value = '';
            document.getElementById('customDateRange').style.display = 'none';
            document.getElementById('dataInicio').value = '';
            document.getElementById('dataFim').value = '';
            renderMovimentacao();
        });
        
        // View toggle
        document.getElementById('timelineViewBtn').addEventListener('click', () => {
            isTimelineView = true;
            toggleView();
        });
        
        document.getElementById('tableViewBtn').addEventListener('click', () => {
            isTimelineView = false;
            toggleView();
        });
    }
    
    function renderMovimentacao() {
        const filteredEventos = applyFilters();
        
        if (isTimelineView) {
            renderTimeline(filteredEventos);
        } else {
            renderTable(filteredEventos);
        }
        
        updateSummary(filteredEventos);
    }
    
    function applyFilters() {
        const search = document.getElementById('searchInput').value.toLowerCase();
        const decisao = document.getElementById('decisaoFilter').value;
        const categoria = document.getElementById('categoriaFilter').value;
        const periodo = document.getElementById('periodoFilter').value;
        
        return currentEventos.filter(evento => {
            // Search filter
            if (search && !evento.placa.toLowerCase().includes(search)) {
                return false;
            }
            
            // Decision filter
            if (decisao && evento.decisao !== decisao) {
                return false;
            }
            
            // Category filter
            if (categoria && evento.categoria !== categoria) {
                return false;
            }
            
            // Period filter
            if (periodo) {
                const now = Date.now();
                const eventDate = new Date(evento.timestamp);
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                
                switch (periodo) {
                    case 'hoje':
                        return eventDate >= today;
                    case 'ontem':
                        const yesterday = new Date(today);
                        yesterday.setDate(yesterday.getDate() - 1);
                        return eventDate >= yesterday && eventDate < today;
                    case 'semana':
                        const weekStart = new Date(today);
                        weekStart.setDate(weekStart.getDate() - weekStart.getDay());
                        return eventDate >= weekStart;
                    case 'mes':
                        const monthStart = new Date(today);
                        monthStart.setDate(1);
                        return eventDate >= monthStart;
                    case 'personalizado':
                        const dataInicio = document.getElementById('dataInicio').value;
                        const dataFim = document.getElementById('dataFim').value;
                        if (dataInicio && dataFim) {
                            const inicio = new Date(dataInicio);
                            const fim = new Date(dataFim);
                            fim.setHours(23, 59, 59, 999);
                            return eventDate >= inicio && eventDate <= fim;
                        }
                        break;
                }
            }
            
            return true;
        });
    }
    
    function renderTimeline(eventos) {
        const timelineContainer = document.getElementById('eventsTimeline');
        
        if (eventos.length === 0) {
            timelineContainer.innerHTML = '<p class="no-data">Nenhum evento encontrado</p>';
            return;
        }
        
        // Sort events by timestamp (newest first)
        const sortedEventos = eventos.sort((a, b) => b.timestamp - a.timestamp);
        
        // Group by date
        const groupedEvents = groupEventsByDate(sortedEventos);
        
        const timelineHTML = Object.entries(groupedEvents).map(([date, dayEvents]) => {
            const eventsHTML = dayEvents.map(evento => {
                const vaga = evento.vagaId ? store.getVagas().find(v => v.id === evento.vagaId) : null;
                const time = new Date(evento.timestamp).toLocaleTimeString('pt-BR', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                });
                
                return `
                    <div class="timeline-event ${evento.decisao.toLowerCase()}" onclick="showEventDetails('${evento.id}')">
                        <div class="event-time">${time}</div>
                        <div class="event-icon">${getEventIcon(evento.decisao)}</div>
                        <div class="event-content">
                            <div class="event-header">
                                <span class="event-placa">${ui.formatPlaca(evento.placa)}</span>
                                <span class="event-badge badge badge-${getEventBadgeType(evento.decisao)}">
                                    ${evento.decisao}
                                </span>
                            </div>
                            <div class="event-details">
                                ${evento.motivo}
                                ${vaga ? ` - Vaga ${vaga.numero}` : ''}
                            </div>
                            <div class="event-meta">
                                ${getCategoriaTexto(evento.categoria)} • ${evento.operador}
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
            
            return `
                <div class="timeline-day">
                    <div class="day-header">${formatDateHeader(date)}</div>
                    <div class="day-events">
                        ${eventsHTML}
                    </div>
                </div>
            `;
        }).join('');
        
        timelineContainer.innerHTML = timelineHTML;
        
        // Make event details function globally accessible
        window.showEventDetails = showEventDetails;
    }
    
    function renderTable(eventos) {
        const tableContainer = document.getElementById('eventsTable');
        
        if (eventos.length === 0) {
            tableContainer.innerHTML = '<p class="no-data">Nenhum evento encontrado</p>';
            return;
        }
        
        const columns = [
            { 
                key: 'timestamp', 
                label: 'Data/Hora', 
                sortable: true,
                render: (value) => ui.formatDate(value, { 
                    year: 'numeric', 
                    month: '2-digit', 
                    day: '2-digit',
                    hour: '2-digit', 
                    minute: '2-digit' 
                })
            },
            { key: 'placa', label: 'Placa', sortable: true, render: (value) => ui.formatPlaca(value) },
            { 
                key: 'decisao', 
                label: 'Decisão', 
                sortable: true,
                render: (value) => `<span class="badge badge-${getEventBadgeType(value)}">${value}</span>`
            },
            { key: 'categoria', label: 'Categoria', sortable: true, render: (value) => getCategoriaTexto(value) },
            { key: 'motivo', label: 'Motivo', sortable: true },
            { 
                key: 'vagaId', 
                label: 'Vaga', 
                render: (value) => {
                    if (!value) return '-';
                    const vaga = store.getVagas().find(v => v.id === value);
                    return vaga ? vaga.numero : '-';
                }
            },
            { key: 'operador', label: 'Operador', sortable: true }
        ];
        
        const table = ui.createTable(eventos, columns, {
            className: 'movimentacao-table',
            sortable: true,
            onRowClick: (evento) => {
                showEventDetails(evento.id);
            }
        });
        
        tableContainer.innerHTML = '';
        tableContainer.appendChild(table);
    }
    
    function toggleView() {
        const timelineView = document.getElementById('timelineView');
        const tableView = document.getElementById('tableView');
        const timelineBtn = document.getElementById('timelineViewBtn');
        const tableBtn = document.getElementById('tableViewBtn');
        
        if (isTimelineView) {
            timelineView.classList.remove('hidden');
            tableView.classList.add('hidden');
            timelineBtn.classList.add('active');
            tableBtn.classList.remove('active');
        } else {
            timelineView.classList.add('hidden');
            tableView.classList.remove('hidden');
            timelineBtn.classList.remove('active');
            tableBtn.classList.add('active');
        }
        
        renderMovimentacao();
    }
    
    function updateSummary(filteredEventos = null) {
        const eventos = filteredEventos || currentEventos;
        
        const autorizados = eventos.filter(e => e.decisao === 'AUTORIZADO').length;
        const negados = eventos.filter(e => e.decisao === 'NEGADO').length;
        const manuais = eventos.filter(e => e.decisao === 'MANUAL').length;
        
        document.getElementById('autorizadosCount').textContent = autorizados;
        document.getElementById('negadosCount').textContent = negados;
        document.getElementById('manuaisCount').textContent = manuais;
        document.getElementById('totalCount').textContent = eventos.length;
    }
    
    function groupEventsByDate(eventos) {
        return eventos.reduce((groups, evento) => {
            const date = new Date(evento.timestamp).toDateString();
            if (!groups[date]) {
                groups[date] = [];
            }
            groups[date].push(evento);
            return groups;
        }, {});
    }
    
    function formatDateHeader(dateString) {
        const date = new Date(dateString);
        const today = new Date();
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        
        if (date.toDateString() === today.toDateString()) {
            return 'Hoje';
        } else if (date.toDateString() === yesterday.toDateString()) {
            return 'Ontem';
        } else {
            return date.toLocaleDateString('pt-BR', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
        }
    }
    
    function showEventDetails(eventId) {
        const evento = currentEventos.find(e => e.id === eventId);
        if (!evento) return;
        
        const vaga = evento.vagaId ? store.getVagas().find(v => v.id === evento.vagaId) : null;
        
        const detailsHTML = `
            <div class="event-details-modal">
                <div class="detail-section">
                    <h4>Informações do Evento</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Data/Hora:</span>
                            <span class="detail-value">${ui.formatDate(evento.timestamp)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Placa:</span>
                            <span class="detail-value">${ui.formatPlaca(evento.placa)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Decisão:</span>
                            <span class="detail-value">
                                <span class="badge badge-${getEventBadgeType(evento.decisao)}">
                                    ${evento.decisao}
                                </span>
                            </span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Categoria:</span>
                            <span class="detail-value">${getCategoriaTexto(evento.categoria)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Operador:</span>
                            <span class="detail-value">${evento.operador}</span>
                        </div>
                        ${vaga ? `
                            <div class="detail-item">
                                <span class="detail-label">Vaga:</span>
                                <span class="detail-value">${vaga.numero} (Setor ${vaga.setor})</span>
                            </div>
                        ` : ''}
                    </div>
                </div>
                
                <div class="detail-section">
                    <h4>Motivo</h4>
                    <p class="motivo-text">${evento.motivo}</p>
                </div>
            </div>
        `;
        
        ui.showModal(detailsHTML, {
            title: `Evento - ${ui.formatPlaca(evento.placa)}`,
            className: 'event-details-modal'
        });
    }
    
    function exportMovimentacao() {
        const filteredEventos = applyFilters();
        
        if (filteredEventos.length === 0) {
            ui.showToast('Nenhum evento para exportar', 'warning');
            return;
        }
        
        const csvData = filteredEventos.map(evento => {
            const vaga = evento.vagaId ? store.getVagas().find(v => v.id === evento.vagaId) : null;
            
            return {
                'Data/Hora': ui.formatDate(evento.timestamp),
                'Placa': evento.placa,
                'Decisão': evento.decisao,
                'Categoria': getCategoriaTexto(evento.categoria),
                'Motivo': evento.motivo,
                'Vaga': vaga ? vaga.numero : '',
                'Setor': vaga ? vaga.setor : '',
                'Operador': evento.operador
            };
        });
        
        const filename = `movimentacao_${new Date().toISOString().split('T')[0]}.csv`;
        ui.downloadCSV(csvData, filename);
        ui.showToast('Arquivo CSV exportado com sucesso', 'success');
    }
    
    function getEventIcon(decisao) {
        const icons = {
            'AUTORIZADO': '✅',
            'NEGADO': '❌',
            'MANUAL': '🔧'
        };
        return icons[decisao] || '📋';
    }
    
    function getEventBadgeType(decisao) {
        const types = {
            'AUTORIZADO': 'success',
            'NEGADO': 'error',
            'MANUAL': 'warning'
        };
        return types[decisao] || 'info';
    }
    
    function getCategoriaTexto(categoria) {
        const categorias = {
            'ALUNO': 'Aluno',
            'FUNCIONARIO': 'Funcionário',
            'PCD': 'PCD',
            'VISITANTE_COMUM': 'Visitante Comum',
            'VISITANTE_ESPECIAL': 'Visitante Especial'
        };
        return categorias[categoria] || categoria;
    }
}