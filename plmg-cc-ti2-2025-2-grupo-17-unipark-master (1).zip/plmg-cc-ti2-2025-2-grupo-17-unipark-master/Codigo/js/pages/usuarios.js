// Users management page - CRUD operations for users (students, employees, system users)
export function render() {
    return `
        <div class="usuarios-container">
            <div class="page-header">
                <div class="header-content">
                    <h1>Gestão de Usuários</h1>
                    <p class="page-description">Cadastro de alunos, funcionários e usuários do sistema</p>
                </div>
                <div class="header-actions">
                    <button id="addUsuarioBtn" class="btn btn-primary">
                        <span class="btn-icon">➕</span>
                        Novo Usuário
                    </button>
                    <button id="importUsuariosBtn" class="btn btn-secondary">
                        <span class="btn-icon">📂</span>
                        Importar CSV
                    </button>
                    <button id="exportUsuariosBtn" class="btn btn-outline">
                        <span class="btn-icon">📄</span>
                        Exportar CSV
                    </button>
                </div>
            </div>
            
            <div class="usuarios-content">
                <!-- Filters -->
                <div class="card filters-card">
                    <div class="filters-section">
                        <div class="filter-row">
                            <div class="form-group">
                                <label class="form-label">Buscar</label>
                                <input type="text" id="searchInput" class="form-input" 
                                       placeholder="Nome, email, matrícula ou placa">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Categoria</label>
                                <select id="categoriaFilter" class="form-select">
                                    <option value="">Todas</option>
                                    <option value="ALUNO">Aluno</option>
                                    <option value="FUNCIONARIO">Funcionário</option>
                                    <option value="PCD">PCD</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Perfil do Sistema</label>
                                <select id="roleFilter" class="form-select">
                                    <option value="">Todos</option>
                                    <option value="ADMIN">Administrador</option>
                                    <option value="ATENDENTE">Atendente</option>
                                    <option value="OPERADOR">Operador</option>
                                    <option value="null">Sem acesso ao sistema</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Status</label>
                                <select id="statusFilter" class="form-select">
                                    <option value="">Todos</option>
                                    <option value="true">Ativo</option>
                                    <option value="false">Inativo</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <button id="clearFiltersBtn" class="btn btn-outline">Limpar</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Users Table -->
                <div class="card table-card">
                    <div id="usuariosTable" class="table-container">
                        <!-- Table will be populated here -->
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Hidden file input for CSV import -->
        <input type="file" id="csvFileInput" accept=".csv" style="display: none;">
    `;
}

export function mount() {
    const store = window.app.getStore();
    const ui = window.app.getUI();
    
    let currentUsuarios = store.getUsuarios();
    
    // Initialize
    renderUsuariosTable();
    setupEventListeners();
    
    // Subscribe to changes
    store.subscribe('usuarios', (usuarios) => {
        currentUsuarios = usuarios;
        renderUsuariosTable();
    });
    
    function setupEventListeners() {
        // Add usuario button
        document.getElementById('addUsuarioBtn').addEventListener('click', () => {
            showUsuarioModal();
        });
        
        // Import button
        document.getElementById('importUsuariosBtn').addEventListener('click', () => {
            document.getElementById('csvFileInput').click();
        });
        
        // File input change
        document.getElementById('csvFileInput').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                importCSV(file);
            }
        });
        
        // Export button
        document.getElementById('exportUsuariosBtn').addEventListener('click', () => {
            exportUsuarios();
        });
        
        // Filters
        document.getElementById('searchInput').addEventListener('input', renderUsuariosTable);
        document.getElementById('categoriaFilter').addEventListener('change', renderUsuariosTable);
        document.getElementById('roleFilter').addEventListener('change', renderUsuariosTable);
        document.getElementById('statusFilter').addEventListener('change', renderUsuariosTable);
        
        // Clear filters
        document.getElementById('clearFiltersBtn').addEventListener('click', () => {
            document.getElementById('searchInput').value = '';
            document.getElementById('categoriaFilter').value = '';
            document.getElementById('roleFilter').value = '';
            document.getElementById('statusFilter').value = '';
            renderUsuariosTable();
        });
    }
    
    function renderUsuariosTable() {
        const filteredUsuarios = applyFilters();
        const tableContainer = document.getElementById('usuariosTable');
        
        if (filteredUsuarios.length === 0) {
            tableContainer.innerHTML = '<p class="no-data">Nenhum usuário encontrado</p>';
            return;
        }
        
        const columns = [
            { key: 'nome', label: 'Nome', sortable: true },
            { key: 'email', label: 'Email', sortable: true },
            { key: 'matricula', label: 'Matrícula', sortable: true },
            { key: 'placa', label: 'Placa', sortable: true, render: (value) => value ? ui.formatPlaca(value) : '-' },
            { key: 'categoria', label: 'Categoria', sortable: true, render: (value) => getCategoriaTexto(value) },
            { 
                key: 'role', 
                label: 'Perfil Sistema', 
                sortable: true, 
                render: (value) => value ? getRoleTexto(value) : '-' 
            },
            { 
                key: 'pcd', 
                label: 'PCD', 
                render: (value) => value ? 
                    '<span class="badge badge-info">Sim</span>' : 
                    '<span class="badge badge-muted">Não</span>' 
            },
            { 
                key: 'ativo', 
                label: 'Status', 
                render: (value) => value ? 
                    '<span class="badge badge-success">Ativo</span>' : 
                    '<span class="badge badge-error">Inativo</span>' 
            },
            {
                key: 'actions',
                label: 'Ações',
                render: (_, usuario) => `
                    <div class="table-actions">
                        <button class="btn btn-sm btn-outline" onclick="editUsuario('${usuario.id}')">
                            ✏️ Editar
                        </button>
                        <button class="btn btn-sm btn-outline" onclick="toggleUsuarioStatus('${usuario.id}')">
                            ${usuario.ativo ? '🚫 Desativar' : '✅ Ativar'}
                        </button>
                        <button class="btn btn-sm btn-outline" onclick="deleteUsuario('${usuario.id}')">
                            🗑️ Excluir
                        </button>
                    </div>
                `
            }
        ];
        
        const table = ui.createTable(filteredUsuarios, columns, {
            className: 'usuarios-table',
            sortable: true,
            onRowClick: (usuario) => {
                showUsuarioDetails(usuario);
            }
        });
        
        tableContainer.innerHTML = '';
        tableContainer.appendChild(table);
        
        // Make action functions globally accessible
        window.editUsuario = editUsuario;
        window.toggleUsuarioStatus = toggleUsuarioStatus;
        window.deleteUsuario = deleteUsuario;
    }
    
    function applyFilters() {
        const search = document.getElementById('searchInput').value.toLowerCase();
        const categoria = document.getElementById('categoriaFilter').value;
        const role = document.getElementById('roleFilter').value;
        const status = document.getElementById('statusFilter').value;
        
        return currentUsuarios.filter(usuario => {
            // Search filter
            if (search && !usuario.nome.toLowerCase().includes(search) &&
                !usuario.email.toLowerCase().includes(search) &&
                !usuario.matricula.toLowerCase().includes(search) &&
                !(usuario.placa && usuario.placa.toLowerCase().includes(search))) {
                return false;
            }
            
            // Category filter
            if (categoria && usuario.categoria !== categoria) {
                return false;
            }
            
            // Role filter
            if (role === 'null' && usuario.role !== null) {
                return false;
            }
            if (role && role !== 'null' && usuario.role !== role) {
                return false;
            }
            
            // Status filter
            if (status !== '' && usuario.ativo.toString() !== status) {
                return false;
            }
            
            return true;
        });
    }
    
    function showUsuarioModal(usuario = null) {
        const isEdit = !!usuario;
        const title = isEdit ? 'Editar Usuário' : 'Novo Usuário';
        
        const formHTML = `
            <form id="usuarioForm">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Nome <span class="required">*</span></label>
                        <input type="text" name="nome" class="form-input" required
                               value="${usuario?.nome || ''}" placeholder="Nome completo">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email <span class="required">*</span></label>
                        <input type="email" name="email" class="form-input" required
                               value="${usuario?.email || ''}" placeholder="usuario@exemplo.com">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Matrícula <span class="required">*</span></label>
                        <input type="text" name="matricula" class="form-input" required
                               value="${usuario?.matricula || ''}" placeholder="Número da matrícula">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Categoria <span class="required">*</span></label>
                        <select name="categoria" class="form-select" required>
                            <option value="">Selecione</option>
                            <option value="ALUNO" ${usuario?.categoria === 'ALUNO' ? 'selected' : ''}>
                                Aluno
                            </option>
                            <option value="FUNCIONARIO" ${usuario?.categoria === 'FUNCIONARIO' ? 'selected' : ''}>
                                Funcionário
                            </option>
                            <option value="PCD" ${usuario?.categoria === 'PCD' ? 'selected' : ''}>
                                PCD
                            </option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Placa do Veículo</label>
                        <input type="text" name="placa" class="form-input"
                               value="${usuario?.placa || ''}" placeholder="ABC-1234">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Perfil do Sistema</label>
                        <select name="role" class="form-select">
                            <option value="">Sem acesso ao sistema</option>
                            <option value="ADMIN" ${usuario?.role === 'ADMIN' ? 'selected' : ''}>
                                Administrador
                            </option>
                            <option value="ATENDENTE" ${usuario?.role === 'ATENDENTE' ? 'selected' : ''}>
                                Atendente
                            </option>
                            <option value="OPERADOR" ${usuario?.role === 'OPERADOR' ? 'selected' : ''}>
                                Operador
                            </option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="pcd" ${usuario?.pcd ? 'checked' : ''}>
                            <span class="checkbox-text">Pessoa com Deficiência (PCD)</span>
                        </label>
                    </div>
                    ${isEdit ? `
                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select name="ativo" class="form-select">
                                <option value="true" ${usuario?.ativo ? 'selected' : ''}>Ativo</option>
                                <option value="false" ${!usuario?.ativo ? 'selected' : ''}>Inativo</option>
                            </select>
                        </div>
                    ` : ''}
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" onclick="ui.closeModal(this.closest('.modal-overlay'))">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary">
                        ${isEdit ? 'Atualizar' : 'Criar'} Usuário
                    </button>
                </div>
            </form>
        `;
        
        const modal = ui.showModal(formHTML, { title, className: 'usuario-modal' });
        
        const form = modal.querySelector('#usuarioForm');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());
            
            // Validate email
            if (!data.email.includes('@')) {
                ui.showToast('Email inválido', 'error');
                return;
            }
            
            // Validate plate if provided
            if (data.placa && !store.validarPlaca(data.placa)) {
                ui.showToast('Placa inválida', 'error');
                return;
            }
            
            // Convert boolean values
            data.pcd = !!data.pcd;
            if (data.ativo !== undefined) {
                data.ativo = data.ativo === 'true';
            }
            
            // Handle empty role
            if (!data.role) {
                data.role = null;
            }
            
            if (isEdit) {
                store.updateUsuario(usuario.id, data);
                ui.showToast('Usuário atualizado com sucesso', 'success');
            } else {
                store.addUsuario(data);
                ui.showToast('Usuário criado com sucesso', 'success');
            }
            
            ui.closeModal(modal);
        });
    }
    
    function showUsuarioDetails(usuario) {
        const detailsHTML = `
            <div class="usuario-details">
                <div class="detail-section">
                    <h4>Informações Pessoais</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Nome:</span>
                            <span class="detail-value">${usuario.nome}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Email:</span>
                            <span class="detail-value">${usuario.email}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Matrícula:</span>
                            <span class="detail-value">${usuario.matricula}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">PCD:</span>
                            <span class="detail-value">
                                <span class="badge badge-${usuario.pcd ? 'info' : 'muted'}">
                                    ${usuario.pcd ? 'Sim' : 'Não'}
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h4>Informações Acadêmicas/Profissionais</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Categoria:</span>
                            <span class="detail-value">${getCategoriaTexto(usuario.categoria)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Perfil do Sistema:</span>
                            <span class="detail-value">${usuario.role ? getRoleTexto(usuario.role) : 'Sem acesso'}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Status:</span>
                            <span class="detail-value">
                                <span class="badge badge-${usuario.ativo ? 'success' : 'error'}">
                                    ${usuario.ativo ? 'Ativo' : 'Inativo'}
                                </span>
                            </span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Criado em:</span>
                            <span class="detail-value">${ui.formatDate(usuario.criadoEm)}</span>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h4>Informações do Veículo</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Placa:</span>
                            <span class="detail-value">${usuario.placa ? ui.formatPlaca(usuario.placa) : 'Não cadastrada'}</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        ui.showModal(detailsHTML, { 
            title: `Usuário: ${usuario.nome}`,
            className: 'usuario-details-modal'
        });
    }
    
    function editUsuario(id) {
        const usuario = currentUsuarios.find(u => u.id === id);
        if (usuario) {
            showUsuarioModal(usuario);
        }
    }
    
    function toggleUsuarioStatus(id) {
        const usuario = currentUsuarios.find(u => u.id === id);
        if (usuario) {
            store.updateUsuario(id, { ativo: !usuario.ativo });
            const status = usuario.ativo ? 'desativado' : 'ativado';
            ui.showToast(`Usuário ${status} com sucesso`, 'success');
        }
    }
    
    function deleteUsuario(id) {
        const usuario = currentUsuarios.find(u => u.id === id);
        if (usuario && confirm(`Deseja realmente excluir o usuário ${usuario.nome}?`)) {
            store.deleteUsuario(id);
            ui.showToast('Usuário excluído com sucesso', 'success');
        }
    }
    
    function importCSV(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const csv = e.target.result;
                const lines = csv.split('\n');
                const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
                
                let imported = 0;
                let errors = 0;
                
                for (let i = 1; i < lines.length; i++) {
                    const line = lines[i].trim();
                    if (!line) continue;
                    
                    const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
                    const userData = {};
                    
                    headers.forEach((header, index) => {
                        const value = values[index] || '';
                        
                        switch (header.toLowerCase()) {
                            case 'nome':
                                userData.nome = value;
                                break;
                            case 'email':
                                userData.email = value;
                                break;
                            case 'matricula':
                            case 'matrícula':
                                userData.matricula = value;
                                break;
                            case 'placa':
                                userData.placa = value;
                                break;
                            case 'categoria':
                                userData.categoria = value.toUpperCase();
                                break;
                            case 'role':
                            case 'perfil':
                                userData.role = value || null;
                                break;
                            case 'pcd':
                                userData.pcd = value.toLowerCase() === 'sim' || value === 'true';
                                break;
                        }
                    });
                    
                    // Validate required fields
                    if (!userData.nome || !userData.email || !userData.matricula || !userData.categoria) {
                        errors++;
                        continue;
                    }
                    
                    try {
                        store.addUsuario(userData);
                        imported++;
                    } catch (error) {
                        errors++;
                    }
                }
                
                ui.showToast(`Importação concluída: ${imported} usuários importados, ${errors} erros`, 
                           errors > 0 ? 'warning' : 'success');
                
            } catch (error) {
                ui.showToast('Erro ao processar arquivo CSV', 'error');
            }
        };
        
        reader.readAsText(file);
    }
    
    function exportUsuarios() {
        const filteredUsuarios = applyFilters();
        
        if (filteredUsuarios.length === 0) {
            ui.showToast('Nenhum usuário para exportar', 'warning');
            return;
        }
        
        const csvData = filteredUsuarios.map(u => ({
            Nome: u.nome,
            Email: u.email,
            Matrícula: u.matricula,
            Placa: u.placa || '',
            Categoria: getCategoriaTexto(u.categoria),
            Perfil: u.role ? getRoleTexto(u.role) : '',
            PCD: u.pcd ? 'Sim' : 'Não',
            Status: u.ativo ? 'Ativo' : 'Inativo',
            'Criado em': ui.formatDate(u.criadoEm)
        }));
        
        const filename = `usuarios_${new Date().toISOString().split('T')[0]}.csv`;
        ui.downloadCSV(csvData, filename);
        ui.showToast('Arquivo CSV exportado com sucesso', 'success');
    }
    
    function getCategoriaTexto(categoria) {
        const categorias = {
            'ALUNO': 'Aluno',
            'FUNCIONARIO': 'Funcionário',
            'PCD': 'PCD'
        };
        return categorias[categoria] || categoria;
    }
    
    function getRoleTexto(role) {
        const roles = {
            'ADMIN': 'Administrador',
            'ATENDENTE': 'Atendente',
            'OPERADOR': 'Operador'
        };
        return roles[role] || role;
    }
}