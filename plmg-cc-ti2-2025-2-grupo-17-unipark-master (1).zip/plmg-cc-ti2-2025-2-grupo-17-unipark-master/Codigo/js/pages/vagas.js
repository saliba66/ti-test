// Parking spots management page - CRUD operations for parking spots
export function render() {
    return `
        <div class="vagas-container">
            <div class="page-header">
                <div class="header-content">
                    <h1>Gestão de Vagas</h1>
                    <p class="page-description">Configuração e controle das vagas de estacionamento</p>
                </div>
                <div class="header-actions">
                    <button id="addVagaBtn" class="btn btn-primary">
                        <span class="btn-icon">➕</span>
                        Nova Vaga
                    </button>
                    <button id="batchActionsBtn" class="btn btn-secondary">
                        <span class="btn-icon">⚙️</span>
                        Ações em Lote
                    </button>
                </div>
            </div>
            
            <div class="vagas-content">
                <!-- Quick Stats -->
                <div class="vagas-stats">
                    <div class="stat-card">
                        <div class="stat-icon">🅿️</div>
                        <div class="stat-info">
                            <span class="stat-value" id="totalVagasStat">0</span>
                            <span class="stat-label">Total</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">✅</div>
                        <div class="stat-info">
                            <span class="stat-value" id="livresStat">0</span>
                            <span class="stat-label">Livres</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">🚗</div>
                        <div class="stat-info">
                            <span class="stat-value" id="ocupadasStat">0</span>
                            <span class="stat-label">Ocupadas</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">🚫</div>
                        <div class="stat-info">
                            <span class="stat-value" id="bloqueadasStat">0</span>
                            <span class="stat-label">Bloqueadas</span>
                        </div>
                    </div>
                </div>
                
                <!-- Filters -->
                <div class="card filters-card">
                    <div class="filters-section">
                        <div class="filter-row">
                            <div class="form-group">
                                <label class="form-label">Buscar</label>
                                <input type="text" id="searchInput" class="form-input" 
                                       placeholder="Número da vaga ou placa">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Setor</label>
                                <select id="setorFilter" class="form-select">
                                    <option value="">Todos</option>
                                    <option value="A">Setor A</option>
                                    <option value="B">Setor B</option>
                                    <option value="C">Setor C</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Tipo</label>
                                <select id="tipoFilter" class="form-select">
                                    <option value="">Todos</option>
                                    <option value="COMUM">Comum</option>
                                    <option value="FUNCIONARIO">Funcionário</option>
                                    <option value="PCD">PCD</option>
                                    <option value="VISITANTE_ESPECIAL">Visitante Especial</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Status</label>
                                <select id="statusFilter" class="form-select">
                                    <option value="">Todos</option>
                                    <option value="LIVRE">Livre</option>
                                    <option value="OCUPADA">Ocupada</option>
                                    <option value="BLOQUEADA">Bloqueada</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <button id="clearFiltersBtn" class="btn btn-outline">Limpar</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Vagas Table -->
                <div class="card table-card">
                    <div id="vagasTable" class="table-container">
                        <!-- Table will be populated here -->
                    </div>
                </div>
            </div>
        </div>
    `;
}

export function mount() {
    const store = window.app.getStore();
    const ui = window.app.getUI();
    
    let currentVagas = store.getVagas();
    
    // Initialize
    renderVagasTable();
    updateStats();
    setupEventListeners();
    
    // Subscribe to changes
    store.subscribe('vagas', (vagas) => {
        currentVagas = vagas;
        renderVagasTable();
        updateStats();
    });
    
    function setupEventListeners() {
        // Add vaga button
        document.getElementById('addVagaBtn').addEventListener('click', () => {
            showVagaModal();
        });
        
        // Batch actions button
        document.getElementById('batchActionsBtn').addEventListener('click', showBatchActions);
        
        // Filters
        document.getElementById('searchInput').addEventListener('input', renderVagasTable);
        document.getElementById('setorFilter').addEventListener('change', renderVagasTable);
        document.getElementById('tipoFilter').addEventListener('change', renderVagasTable);
        document.getElementById('statusFilter').addEventListener('change', renderVagasTable);
        
        // Clear filters
        document.getElementById('clearFiltersBtn').addEventListener('click', () => {
            document.getElementById('searchInput').value = '';
            document.getElementById('setorFilter').value = '';
            document.getElementById('tipoFilter').value = '';
            document.getElementById('statusFilter').value = '';
            renderVagasTable();
        });
    }
    
    function renderVagasTable() {
        const filteredVagas = applyFilters();
        const tableContainer = document.getElementById('vagasTable');
        
        if (filteredVagas.length === 0) {
            tableContainer.innerHTML = '<p class="no-data">Nenhuma vaga encontrada</p>';
            return;
        }
        
        const columns = [
            { key: 'numero', label: 'Número', sortable: true },
            { key: 'setor', label: 'Setor', sortable: true },
            { 
                key: 'tipo', 
                label: 'Tipo', 
                sortable: true, 
                render: (value) => getTipoTexto(value)
            },
            { 
                key: 'status', 
                label: 'Status', 
                sortable: true, 
                render: (value, vaga) => {
                    const badgeClass = {
                        'LIVRE': 'success',
                        'OCUPADA': 'error',
                        'BLOQUEADA': 'warning'
                    }[value];
                    return `<span class="badge badge-${badgeClass}">${getStatusTexto(value)}</span>`;
                }
            },
            { 
                key: 'placaAtual', 
                label: 'Placa Atual', 
                render: (value) => value ? ui.formatPlaca(value) : '-'
            },
            { 
                key: 'desde', 
                label: 'Ocupada desde', 
                render: (value) => value ? ui.formatDate(value) : '-'
            },
            { key: 'observacoes', label: 'Observações', render: (value) => value || '-' },
            {
                key: 'actions',
                label: 'Ações',
                render: (_, vaga) => `
                    <div class="table-actions">
                        <button class="btn btn-sm btn-outline" onclick="editVaga('${vaga.id}')">
                            ✏️ Editar
                        </button>
                        ${vaga.status === 'OCUPADA' ? `
                            <button class="btn btn-sm btn-outline" onclick="liberarVaga('${vaga.id}')">
                                🚪 Liberar
                            </button>
                        ` : ''}
                        <button class="btn btn-sm btn-outline" onclick="toggleBloqueio('${vaga.id}')">
                            ${vaga.status === 'BLOQUEADA' ? '✅ Desbloquear' : '🚫 Bloquear'}
                        </button>
                        <button class="btn btn-sm btn-outline" onclick="deleteVaga('${vaga.id}')">
                            🗑️ Excluir
                        </button>
                    </div>
                `
            }
        ];
        
        const table = ui.createTable(filteredVagas, columns, {
            className: 'vagas-table',
            sortable: true,
            onRowClick: (vaga) => {
                showVagaDetails(vaga);
            }
        });
        
        tableContainer.innerHTML = '';
        tableContainer.appendChild(table);
        
        // Make action functions globally accessible
        window.editVaga = editVaga;
        window.liberarVaga = liberarVaga;
        window.toggleBloqueio = toggleBloqueio;
        window.deleteVaga = deleteVaga;
    }
    
    function applyFilters() {
        const search = document.getElementById('searchInput').value.toLowerCase();
        const setor = document.getElementById('setorFilter').value;
        const tipo = document.getElementById('tipoFilter').value;
        const status = document.getElementById('statusFilter').value;
        
        return currentVagas.filter(vaga => {
            // Search filter
            if (search && !vaga.numero.toLowerCase().includes(search) &&
                !(vaga.placaAtual && vaga.placaAtual.toLowerCase().includes(search))) {
                return false;
            }
            
            // Setor filter
            if (setor && vaga.setor !== setor) {
                return false;
            }
            
            // Tipo filter
            if (tipo && vaga.tipo !== tipo) {
                return false;
            }
            
            // Status filter
            if (status && vaga.status !== status) {
                return false;
            }
            
            return true;
        });
    }
    
    function updateStats() {
        const livres = currentVagas.filter(v => v.status === 'LIVRE').length;
        const ocupadas = currentVagas.filter(v => v.status === 'OCUPADA').length;
        const bloqueadas = currentVagas.filter(v => v.status === 'BLOQUEADA').length;
        
        document.getElementById('totalVagasStat').textContent = currentVagas.length;
        document.getElementById('livresStat').textContent = livres;
        document.getElementById('ocupadasStat').textContent = ocupadas;
        document.getElementById('bloqueadasStat').textContent = bloqueadas;
    }
    
    function showVagaModal(vaga = null) {
        const isEdit = !!vaga;
        const title = isEdit ? 'Editar Vaga' : 'Nova Vaga';
        
        const formHTML = `
            <form id="vagaForm">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Número <span class="required">*</span></label>
                        <input type="text" name="numero" class="form-input" required
                               value="${vaga?.numero || ''}" placeholder="A01, B15, etc.">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Setor <span class="required">*</span></label>
                        <select name="setor" class="form-select" required>
                            <option value="">Selecione</option>
                            <option value="A" ${vaga?.setor === 'A' ? 'selected' : ''}>Setor A</option>
                            <option value="B" ${vaga?.setor === 'B' ? 'selected' : ''}>Setor B</option>
                            <option value="C" ${vaga?.setor === 'C' ? 'selected' : ''}>Setor C</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Tipo <span class="required">*</span></label>
                        <select name="tipo" class="form-select" required>
                            <option value="">Selecione</option>
                            <option value="COMUM" ${vaga?.tipo === 'COMUM' ? 'selected' : ''}>
                                Comum
                            </option>
                            <option value="FUNCIONARIO" ${vaga?.tipo === 'FUNCIONARIO' ? 'selected' : ''}>
                                Funcionário
                            </option>
                            <option value="PCD" ${vaga?.tipo === 'PCD' ? 'selected' : ''}>
                                PCD
                            </option>
                            <option value="VISITANTE_ESPECIAL" ${vaga?.tipo === 'VISITANTE_ESPECIAL' ? 'selected' : ''}>
                                Visitante Especial
                            </option>
                        </select>
                    </div>
                    ${isEdit ? `
                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="LIVRE" ${vaga?.status === 'LIVRE' ? 'selected' : ''}>Livre</option>
                                <option value="BLOQUEADA" ${vaga?.status === 'BLOQUEADA' ? 'selected' : ''}>Bloqueada</option>
                            </select>
                        </div>
                    ` : ''}
                </div>
                
                <div class="form-group">
                    <label class="form-label">Observações</label>
                    <textarea name="observacoes" class="form-textarea" rows="3"
                              placeholder="Informações adicionais sobre a vaga">${vaga?.observacoes || ''}</textarea>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" onclick="ui.closeModal(this.closest('.modal-overlay'))">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary">
                        ${isEdit ? 'Atualizar' : 'Criar'} Vaga
                    </button>
                </div>
            </form>
        `;
        
        const modal = ui.showModal(formHTML, { title, className: 'vaga-modal' });
        
        const form = modal.querySelector('#vagaForm');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());
            
            if (isEdit) {
                store.updateVaga(vaga.id, data);
                ui.showToast('Vaga atualizada com sucesso', 'success');
            } else {
                store.addVaga(data);
                ui.showToast('Vaga criada com sucesso', 'success');
            }
            
            ui.closeModal(modal);
        });
    }
    
    function showVagaDetails(vaga) {
        const detailsHTML = `
            <div class="vaga-details">
                <div class="detail-section">
                    <h4>Informações da Vaga</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Número:</span>
                            <span class="detail-value">${vaga.numero}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Setor:</span>
                            <span class="detail-value">${vaga.setor}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Tipo:</span>
                            <span class="detail-value">${getTipoTexto(vaga.tipo)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Status:</span>
                            <span class="detail-value">
                                <span class="badge badge-${getStatusBadge(vaga.status)}">
                                    ${getStatusTexto(vaga.status)}
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
                
                ${vaga.status === 'OCUPADA' ? `
                    <div class="detail-section">
                        <h4>Ocupação Atual</h4>
                        <div class="detail-grid">
                            <div class="detail-item">
                                <span class="detail-label">Placa:</span>
                                <span class="detail-value">${ui.formatPlaca(vaga.placaAtual)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Desde:</span>
                                <span class="detail-value">${ui.formatDate(vaga.desde)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Tempo:</span>
                                <span class="detail-value">${getTempoOcupacao(vaga.desde)}</span>
                            </div>
                        </div>
                    </div>
                ` : ''}
                
                ${vaga.observacoes ? `
                    <div class="detail-section">
                        <h4>Observações</h4>
                        <p class="observacoes-text">${vaga.observacoes}</p>
                    </div>
                ` : ''}
            </div>
        `;
        
        ui.showModal(detailsHTML, { 
            title: `Vaga ${vaga.numero}`,
            className: 'vaga-details-modal'
        });
    }
    
    function showBatchActions() {
        const formHTML = `
            <div class="batch-actions">
                <h4>Selecionar Vagas</h4>
                <div class="batch-filters">
                    <div class="form-group">
                        <label class="form-label">Setor</label>
                        <select id="batchSetor" class="form-select">
                            <option value="">Todos os setores</option>
                            <option value="A">Setor A</option>
                            <option value="B">Setor B</option>
                            <option value="C">Setor C</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tipo</label>
                        <select id="batchTipo" class="form-select">
                            <option value="">Todos os tipos</option>
                            <option value="COMUM">Comum</option>
                            <option value="FUNCIONARIO">Funcionário</option>
                            <option value="PCD">PCD</option>
                            <option value="VISITANTE_ESPECIAL">Visitante Especial</option>
                        </select>
                    </div>
                </div>
                
                <h4>Ações Disponíveis</h4>
                <div class="batch-action-buttons">
                    <button id="batchBlock" class="btn btn-warning">
                        🚫 Bloquear Selecionadas
                    </button>
                    <button id="batchUnblock" class="btn btn-success">
                        ✅ Desbloquear Selecionadas
                    </button>
                    <button id="batchRelease" class="btn btn-primary">
                        🚪 Liberar Ocupadas
                    </button>
                    <button id="batchChangeType" class="btn btn-secondary">
                        🔄 Alterar Tipo
                    </button>
                </div>
            </div>
        `;
        
        const modal = ui.showModal(formHTML, {
            title: 'Ações em Lote',
            className: 'batch-actions-modal'
        });
        
        // Setup batch action handlers
        modal.querySelector('#batchBlock').addEventListener('click', () => performBatchAction('block'));
        modal.querySelector('#batchUnblock').addEventListener('click', () => performBatchAction('unblock'));
        modal.querySelector('#batchRelease').addEventListener('click', () => performBatchAction('release'));
        modal.querySelector('#batchChangeType').addEventListener('click', () => performBatchAction('changeType'));
        
        function performBatchAction(action) {
            const setor = modal.querySelector('#batchSetor').value;
            const tipo = modal.querySelector('#batchTipo').value;
            
            const targetVagas = currentVagas.filter(vaga => {
                if (setor && vaga.setor !== setor) return false;
                if (tipo && vaga.tipo !== tipo) return false;
                return true;
            });
            
            if (targetVagas.length === 0) {
                ui.showToast('Nenhuma vaga selecionada', 'warning');
                return;
            }
            
            const confirmation = confirm(`Esta ação afetará ${targetVagas.length} vaga(s). Deseja continuar?`);
            if (!confirmation) return;
            
            let count = 0;
            
            switch (action) {
                case 'block':
                    targetVagas.forEach(vaga => {
                        if (vaga.status !== 'BLOQUEADA') {
                            store.updateVaga(vaga.id, { 
                                status: 'BLOQUEADA',
                                placaAtual: null,
                                desde: null
                            });
                            count++;
                        }
                    });
                    ui.showToast(`${count} vaga(s) bloqueada(s)`, 'success');
                    break;
                    
                case 'unblock':
                    targetVagas.forEach(vaga => {
                        if (vaga.status === 'BLOQUEADA') {
                            store.updateVaga(vaga.id, { status: 'LIVRE' });
                            count++;
                        }
                    });
                    ui.showToast(`${count} vaga(s) desbloqueada(s)`, 'success');
                    break;
                    
                case 'release':
                    targetVagas.forEach(vaga => {
                        if (vaga.status === 'OCUPADA') {
                            store.updateVaga(vaga.id, {
                                status: 'LIVRE',
                                placaAtual: null,
                                desde: null
                            });
                            count++;
                        }
                    });
                    ui.showToast(`${count} vaga(s) liberada(s)`, 'success');
                    break;
                    
                case 'changeType':
                    const newType = prompt('Novo tipo (COMUM, FUNCIONARIO, PCD, VISITANTE_ESPECIAL):');
                    if (newType && ['COMUM', 'FUNCIONARIO', 'PCD', 'VISITANTE_ESPECIAL'].includes(newType)) {
                        targetVagas.forEach(vaga => {
                            store.updateVaga(vaga.id, { tipo: newType });
                            count++;
                        });
                        ui.showToast(`${count} vaga(s) alterada(s) para ${getTipoTexto(newType)}`, 'success');
                    }
                    break;
            }
            
            ui.closeModal(modal);
        }
    }
    
    function editVaga(id) {
        const vaga = currentVagas.find(v => v.id === id);
        if (vaga) {
            showVagaModal(vaga);
        }
    }
    
    function liberarVaga(id) {
        const result = store.liberarVaga(id);
        if (result.success) {
            ui.showToast('Vaga liberada com sucesso', 'success');
        } else {
            ui.showToast(result.motivo, 'error');
        }
    }
    
    function toggleBloqueio(id) {
        const vaga = currentVagas.find(v => v.id === id);
        if (vaga) {
            const novoStatus = vaga.status === 'BLOQUEADA' ? 'LIVRE' : 'BLOQUEADA';
            const updates = { status: novoStatus };
            
            if (novoStatus === 'BLOQUEADA') {
                updates.placaAtual = null;
                updates.desde = null;
            }
            
            store.updateVaga(id, updates);
            const acao = novoStatus === 'BLOQUEADA' ? 'bloqueada' : 'desbloqueada';
            ui.showToast(`Vaga ${acao} com sucesso`, 'success');
        }
    }
    
    function deleteVaga(id) {
        const vaga = currentVagas.find(v => v.id === id);
        if (vaga && confirm(`Deseja realmente excluir a vaga ${vaga.numero}?`)) {
            store.deleteVaga(id);
            ui.showToast('Vaga excluída com sucesso', 'success');
        }
    }
    
    function getTipoTexto(tipo) {
        const tipos = {
            'COMUM': 'Comum',
            'FUNCIONARIO': 'Funcionário',
            'PCD': 'PCD',
            'VISITANTE_ESPECIAL': 'Visitante Especial'
        };
        return tipos[tipo] || tipo;
    }
    
    function getStatusTexto(status) {
        const statuses = {
            'LIVRE': 'Livre',
            'OCUPADA': 'Ocupada',
            'BLOQUEADA': 'Bloqueada'
        };
        return statuses[status] || status;
    }
    
    function getStatusBadge(status) {
        const badges = {
            'LIVRE': 'success',
            'OCUPADA': 'error',
            'BLOQUEADA': 'warning'
        };
        return badges[status] || 'info';
    }
    
    function getTempoOcupacao(desde) {
        const agora = Date.now();
        const diff = agora - desde;
        const hours = Math.floor(diff / (60 * 60 * 1000));
        const minutes = Math.floor((diff % (60 * 60 * 1000)) / (60 * 1000));
        
        return `${hours}h ${minutes}m`;
    }
}