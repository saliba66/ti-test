// Parking map page - interactive grid view of all parking spots
export function render() {
    return `
        <div class="mapa-container">
            <div class="page-header">
                <h1>Mapa do Estacionamento</h1>
                <p class="page-description">Visualização em tempo real das vagas</p>
            </div>
            
            <div class="mapa-layout">
                <!-- Filters and Legend -->
                <div class="mapa-sidebar">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Filtros</h3>
                        </div>
                        <div class="filter-section">
                            <div class="form-group">
                                <label class="form-label">Setor</label>
                                <select id="setorFilter" class="form-select">
                                    <option value="">Todos os setores</option>
                                    <option value="A">Setor A</option>
                                    <option value="B">Setor B</option>
                                    <option value="C">Setor C</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Status</label>
                                <select id="statusFilter" class="form-select">
                                    <option value="">Todos os status</option>
                                    <option value="LIVRE">Livre</option>
                                    <option value="OCUPADA">Ocupada</option>
                                    <option value="BLOQUEADA">Bloqueada</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Tipo</label>
                                <select id="tipoFilter" class="form-select">
                                    <option value="">Todos os tipos</option>
                                    <option value="COMUM">Comum</option>
                                    <option value="FUNCIONARIO">Funcionário</option>
                                    <option value="PCD">PCD</option>
                                    <option value="VISITANTE_ESPECIAL">Visitante Especial</option>
                                </select>
                            </div>
                            
                            <button id="clearFilters" class="btn btn-outline">Limpar Filtros</button>
                        </div>
                    </div>
                    
                    <!-- Legend -->
                    <div class="card legend-card">
                        <div class="card-header">
                            <h3 class="card-title">Legenda</h3>
                        </div>
                        <div class="legend-section">
                            <div class="legend-item">
                                <div class="legend-color livre"></div>
                                <span>Livre</span>
                            </div>
                            <div class="legend-item">
                                <div class="legend-color ocupada"></div>
                                <span>Ocupada</span>
                            </div>
                            <div class="legend-item">
                                <div class="legend-color bloqueada"></div>
                                <span>Bloqueada</span>
                            </div>
                            <div class="legend-item">
                                <div class="legend-color pcd"></div>
                                <span>PCD</span>
                            </div>
                            <div class="legend-item">
                                <div class="legend-color funcionario"></div>
                                <span>Funcionário</span>
                            </div>
                            <div class="legend-item">
                                <div class="legend-color visitante-especial"></div>
                                <span>VIP</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Quick Actions -->
                    <div class="card actions-card">
                        <div class="card-header">
                            <h3 class="card-title">Ações Rápidas</h3>
                        </div>
                        <div class="actions-section">
                            <button id="liberarVagaBtn" class="btn btn-primary" disabled>
                                Liberar Vaga
                            </button>
                            <button id="ocuparVagaBtn" class="btn btn-secondary" disabled>
                                Ocupar Vaga
                            </button>
                            <button id="bloquearVagaBtn" class="btn btn-outline" disabled>
                                Bloquear/Desbloquear
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Main Map Area -->
                <div class="mapa-main">
                    <div class="mapa-stats">
                        <div class="stat-item">
                            <span class="stat-label">Total:</span>
                            <span id="totalVagas" class="stat-value">0</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Livres:</span>
                            <span id="vagasLivres" class="stat-value">0</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Ocupadas:</span>
                            <span id="vagasOcupadas" class="stat-value">0</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Bloqueadas:</span>
                            <span id="vagasBloqueadas" class="stat-value">0</span>
                        </div>
                    </div>
                    
                    <div class="parking-sectors">
                        <div class="sector-container" id="setorA">
                            <h3 class="sector-title">Setor A</h3>
                            <div class="parking-grid" id="gridSetorA"></div>
                        </div>
                        
                        <div class="sector-container" id="setorB">
                            <h3 class="sector-title">Setor B</h3>
                            <div class="parking-grid" id="gridSetorB"></div>
                        </div>
                        
                        <div class="sector-container" id="setorC">
                            <h3 class="sector-title">Setor C</h3>
                            <div class="parking-grid" id="gridSetorC"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tooltip -->
        <div id="vagaTooltip" class="vaga-tooltip hidden">
            <div class="tooltip-content">
                <div id="tooltipInfo"></div>
            </div>
        </div>
    `;
}

export function mount() {
    const store = window.app.getStore();
    const ui = window.app.getUI();
    
    let selectedVaga = null;
    let filteredVagas = store.getVagas();
    
    // Initialize map
    renderParkingMap(filteredVagas);
    updateStats(filteredVagas);
    
    // Event listeners
    setupEventListeners();
    setupTooltip();
    
    // Subscribe to data changes
    store.subscribe('vagas', (vagas) => {
        filteredVagas = applyFilters(vagas);
        renderParkingMap(filteredVagas);
        updateStats(filteredVagas);
        updateSelectedVaga();
    });
    
    function setupEventListeners() {
        // Filter changes
        document.getElementById('setorFilter').addEventListener('change', applyFiltersAndUpdate);
        document.getElementById('statusFilter').addEventListener('change', applyFiltersAndUpdate);
        document.getElementById('tipoFilter').addEventListener('change', applyFiltersAndUpdate);
        
        // Clear filters
        document.getElementById('clearFilters').addEventListener('click', () => {
            document.getElementById('setorFilter').value = '';
            document.getElementById('statusFilter').value = '';
            document.getElementById('tipoFilter').value = '';
            applyFiltersAndUpdate();
        });
        
        // Action buttons
        document.getElementById('liberarVagaBtn').addEventListener('click', () => {
            if (selectedVaga && selectedVaga.status === 'OCUPADA') {
                liberarVaga(selectedVaga);
            }
        });
        
        document.getElementById('ocuparVagaBtn').addEventListener('click', () => {
            if (selectedVaga && selectedVaga.status === 'LIVRE') {
                mostrarDialogoOcuparVaga(selectedVaga);
            }
        });
        
        document.getElementById('bloquearVagaBtn').addEventListener('click', () => {
            if (selectedVaga) {
                alternarBloqueioVaga(selectedVaga);
            }
        });
    }
    
    function applyFiltersAndUpdate() {
        filteredVagas = applyFilters(store.getVagas());
        renderParkingMap(filteredVagas);
        updateStats(filteredVagas);
    }
    
    function applyFilters(vagas) {
        const setorFilter = document.getElementById('setorFilter').value;
        const statusFilter = document.getElementById('statusFilter').value;
        const tipoFilter = document.getElementById('tipoFilter').value;
        
        return vagas.filter(vaga => {
            if (setorFilter && vaga.setor !== setorFilter) return false;
            if (statusFilter && vaga.status !== statusFilter) return false;
            if (tipoFilter && vaga.tipo !== tipoFilter) return false;
            return true;
        });
    }
    
    function renderParkingMap(vagas) {
        const setores = ['A', 'B', 'C'];
        
        setores.forEach(setor => {
            const grid = document.getElementById(`gridSetor${setor}`);
            if (!grid) return;
            
            const vagasSetor = vagas.filter(v => v.setor === setor);
            
            grid.innerHTML = vagasSetor.map(vaga => {
                const classes = getVagaClasses(vaga);
                return `
                    <div class="parking-spot ${classes}" 
                         data-vaga-id="${vaga.id}"
                         role="button"
                         tabindex="0"
                         aria-label="Vaga ${vaga.numero} - ${vaga.status}">
                        ${vaga.numero}
                    </div>
                `;
            }).join('');
            
            // Add click listeners to spots
            grid.querySelectorAll('.parking-spot').forEach(spot => {
                spot.addEventListener('click', () => {
                    const vagaId = spot.dataset.vagaId;
                    selectVaga(vagas.find(v => v.id === vagaId));
                });
            });
        });
    }
    
    function getVagaClasses(vaga) {
        const classes = [vaga.status.toLowerCase()];
        
        if (vaga.tipo !== 'COMUM') {
            classes.push(vaga.tipo.toLowerCase().replace('_', '-'));
        }
        
        if (selectedVaga && selectedVaga.id === vaga.id) {
            classes.push('selected');
        }
        
        return classes.join(' ');
    }
    
    function selectVaga(vaga) {
        selectedVaga = vaga;
        
        // Update visual selection
        document.querySelectorAll('.parking-spot').forEach(spot => {
            spot.classList.remove('selected');
        });
        
        const spotElement = document.querySelector(`[data-vaga-id="${vaga.id}"]`);
        if (spotElement) {
            spotElement.classList.add('selected');
        }
        
        updateActionButtons();
    }
    
    function updateActionButtons() {
        const liberarBtn = document.getElementById('liberarVagaBtn');
        const ocuparBtn = document.getElementById('ocuparVagaBtn');
        const bloquearBtn = document.getElementById('bloquearVagaBtn');
        
        if (!selectedVaga) {
            liberarBtn.disabled = true;
            ocuparBtn.disabled = true;
            bloquearBtn.disabled = true;
            return;
        }
        
        liberarBtn.disabled = selectedVaga.status !== 'OCUPADA';
        ocuparBtn.disabled = selectedVaga.status !== 'LIVRE';
        bloquearBtn.disabled = false;
        
        bloquearBtn.textContent = selectedVaga.status === 'BLOQUEADA' ? 'Desbloquear' : 'Bloquear';
    }
    
    function updateSelectedVaga() {
        if (selectedVaga) {
            const updatedVaga = store.getVagas().find(v => v.id === selectedVaga.id);
            if (updatedVaga) {
                selectedVaga = updatedVaga;
                updateActionButtons();
            }
        }
    }
    
    function updateStats(vagas) {
        document.getElementById('totalVagas').textContent = vagas.length;
        document.getElementById('vagasLivres').textContent = 
            vagas.filter(v => v.status === 'LIVRE').length;
        document.getElementById('vagasOcupadas').textContent = 
            vagas.filter(v => v.status === 'OCUPADA').length;
        document.getElementById('vagasBloqueadas').textContent = 
            vagas.filter(v => v.status === 'BLOQUEADA').length;
    }
    
    function setupTooltip() {
        const tooltip = document.getElementById('vagaTooltip');
        
        document.addEventListener('mouseover', (e) => {
            const spot = e.target.closest('.parking-spot');
            if (spot) {
                const vagaId = spot.dataset.vagaId;
                const vaga = store.getVagas().find(v => v.id === vagaId);
                if (vaga) {
                    showTooltip(e, vaga);
                }
            }
        });
        
        document.addEventListener('mouseout', (e) => {
            const spot = e.target.closest('.parking-spot');
            if (spot) {
                hideTooltip();
            }
        });
        
        function showTooltip(event, vaga) {
            const tooltipInfo = document.getElementById('tooltipInfo');
            
            let tempoOcupacao = '';
            if (vaga.status === 'OCUPADA' && vaga.desde) {
                const hours = Math.floor((Date.now() - vaga.desde) / (60 * 60 * 1000));
                const minutes = Math.floor((Date.now() - vaga.desde) / (60 * 1000)) % 60;
                tempoOcupacao = `<div><strong>Tempo:</strong> ${hours}h ${minutes}m</div>`;
            }
            
            tooltipInfo.innerHTML = `
                <div><strong>Vaga:</strong> ${vaga.numero}</div>
                <div><strong>Setor:</strong> ${vaga.setor}</div>
                <div><strong>Tipo:</strong> ${getTipoTexto(vaga.tipo)}</div>
                <div><strong>Status:</strong> ${getStatusTexto(vaga.status)}</div>
                ${vaga.placaAtual ? `<div><strong>Placa:</strong> ${ui.formatPlaca(vaga.placaAtual)}</div>` : ''}
                ${tempoOcupacao}
                ${vaga.observacoes ? `<div><strong>Obs:</strong> ${vaga.observacoes}</div>` : ''}
            `;
            
            tooltip.style.left = `${event.pageX + 10}px`;
            tooltip.style.top = `${event.pageY + 10}px`;
            tooltip.classList.remove('hidden');
        }
        
        function hideTooltip() {
            tooltip.classList.add('hidden');
        }
    }
    
    function liberarVaga(vaga) {
        const result = store.liberarVaga(vaga.id);
        if (result.success) {
            ui.showToast(`Vaga ${vaga.numero} liberada com sucesso`, 'success');
        } else {
            ui.showToast(result.motivo, 'error');
        }
    }
    
    function mostrarDialogoOcuparVaga(vaga) {
        const formHTML = `
            <form id="ocuparVagaForm">
                <div class="form-group">
                    <label class="form-label">Placa do Veículo</label>
                    <input type="text" id="placaInput" class="form-input" 
                           placeholder="ABC-1234" required maxlength="8">
                </div>
                <div class="form-group">
                    <label class="form-label">Categoria</label>
                    <select id="categoriaInput" class="form-select" required>
                        <option value="">Selecione a categoria</option>
                        <option value="ALUNO">Aluno</option>
                        <option value="FUNCIONARIO">Funcionário</option>
                        <option value="PCD">PCD</option>
                        <option value="VISITANTE_COMUM">Visitante Comum</option>
                        <option value="VISITANTE_ESPECIAL">Visitante Especial</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" onclick="ui.closeModal(this.closest('.modal-overlay'))">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary">
                        Ocupar Vaga
                    </button>
                </div>
            </form>
        `;
        
        const modal = ui.showModal(formHTML, {
            title: `Ocupar Vaga ${vaga.numero}`,
            closable: true
        });
        
        const form = modal.querySelector('#ocuparVagaForm');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const placa = document.getElementById('placaInput').value;
            const categoria = document.getElementById('categoriaInput').value;
            
            if (!store.validarPlaca(placa)) {
                ui.showToast('Placa inválida', 'error');
                return;
            }
            
            // Manually occupy the spot
            store.updateVaga(vaga.id, {
                status: 'OCUPADA',
                placaAtual: store.normalizarPlaca(placa),
                desde: Date.now()
            });
            
            store.addEvento({
                placa: store.normalizarPlaca(placa),
                decisao: 'MANUAL',
                motivo: `Vaga ${vaga.numero} ocupada manualmente`,
                vagaId: vaga.id,
                categoria,
                operador: window.app.getCurrentUser()?.role || 'MANUAL'
            });
            
            ui.closeModal(modal);
            ui.showToast(`Vaga ${vaga.numero} ocupada com sucesso`, 'success');
        });
    }
    
    function alternarBloqueioVaga(vaga) {
        const novoStatus = vaga.status === 'BLOQUEADA' ? 'LIVRE' : 'BLOQUEADA';
        const updates = { status: novoStatus };
        
        if (novoStatus === 'BLOQUEADA') {
            // Clear occupation if blocking
            updates.placaAtual = null;
            updates.desde = null;
        }
        
        store.updateVaga(vaga.id, updates);
        
        const acao = novoStatus === 'BLOQUEADA' ? 'bloqueada' : 'desbloqueada';
        ui.showToast(`Vaga ${vaga.numero} ${acao} com sucesso`, 'success');
    }
}

function getTipoTexto(tipo) {
    const tipos = {
        'COMUM': 'Comum',
        'FUNCIONARIO': 'Funcionário',
        'PCD': 'PCD',
        'VISITANTE_ESPECIAL': 'Visitante Especial'
    };
    return tipos[tipo] || tipo;
}

function getStatusTexto(status) {
    const statuses = {
        'LIVRE': 'Livre',
        'OCUPADA': 'Ocupada',
        'BLOQUEADA': 'Bloqueada'
    };
    return statuses[status] || status;
}