// ARQUIVO: Código/js/pages/cadastro-admin.js

/**
 * Renderiza o conteúdo HTML para a página de Cadastro de Novo Administrador.
 */
export function render() {
    return `
        <div class="page-container">
            <h1 class="page-title">Cadastro de Novo Administrador</h1>
            <p class="page-description">Preencha os dados do novo administrador, incluindo CPF, perfil e senha de acesso.</p>

            <div class="card" style="max-width: 600px; margin: 1.5rem auto;">
                <h3 class="card-title">Dados do Administrador</h3>
                <form id="adminForm" style="margin-top: 1rem;">

                    <div class="form-group">
                        <label for="cpf" class="form-label">CPF (Será usado como Login)</label>
                        <input type="text" id="cpf" class="form-input" placeholder="Ex: 000.000.000-00" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="nome" class="form-label">Nome Completo</label>
                        <input type="text" id="nome" class="form-input" required>
                    </div>

                    <div class="form-group">
                        <label for="tipo" class="form-label">Tipo de Administrador</label>
                        <select id="tipo" class="form-select" required>
                            <option value="Master">Master</option>
                            <option value="Gestor">Gestor</option>
                            <option value="Monitor">Monitor</option>
                        </select>
                    </div>

                    <div class="grid grid-cols-2" style="gap: 1rem;">
                        <div class="form-group">
                            <label for="senha" class="form-label">Senha</label>
                            <input type="password" id="senha" class="form-input" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirmarSenha" class="form-label">Confirmar Senha</label>
                            <input type="password" id="confirmarSenha" class="form-input" required>
                        </div>
                    </div>


                    <div style="display: flex; justify-content: flex-end; margin-top: 2rem;">
                        <button type="submit" class="btn btn-primary" style="font-size: 1rem;">
                            Cadastrar Administrador
                        </button>
                    </div>
                </form>
            </div>
        </div>
    `;
}

/**
 * Função de montagem vazia, mantida para evitar erros de roteamento.
 */
export function mount() {
    console.log('Página de Cadastro de Administrador carregada.');
}