// Reports page - analytics and KPIs with simple SVG charts
export function render() {
    return `
        <div class="relatorios-container">
            <div class="page-header">
                <h1>Relatórios</h1>
                <p class="page-description">Análises e estatísticas do estacionamento</p>
            </div>
            
            <div class="relatorios-content">
                <!-- KPIs Overview -->
                <div class="kpis-section">
                    <h2>Indicadores Principais</h2>
                    <div class="grid grid-cols-4" id="kpisGrid">
                        <!-- KPI cards will be populated here -->
                    </div>
                </div>
                
                <!-- Charts Section -->
                <div class="charts-section">
                    <div class="chart-row">
                        <!-- Occupancy Chart -->
                        <div class="card chart-card">
                            <div class="card-header">
                                <h3 class="card-title">Taxa de Ocupação por Hora</h3>
                                <p class="card-description">Últimas 24 horas</p>
                            </div>
                            <div id="occupancyChart" class="chart-container">
                                <!-- Chart will be generated here -->
                            </div>
                        </div>
                        
                        <!-- Category Distribution -->
                        <div class="card chart-card">
                            <div class="card-header">
                                <h3 class="card-title">Distribuição por Categoria</h3>
                                <p class="card-description">Entradas hoje</p>
                            </div>
                            <div id="categoryChart" class="chart-container">
                                <!-- Chart will be generated here -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="chart-row">
                        <!-- Entry Decisions -->
                        <div class="card chart-card">
                            <div class="card-header">
                                <h3 class="card-title">Decisões de Entrada</h3>
                                <p class="card-description">Últimos 7 dias</p>
                            </div>
                            <div id="decisionsChart" class="chart-container">
                                <!-- Chart will be generated here -->
                            </div>
                        </div>
                        
                        <!-- Peak Hours -->
                        <div class="card chart-card">
                            <div class="card-header">
                                <h3 class="card-title">Horários de Pico</h3>
                                <p class="card-description">Entradas por hora (média)</p>
                            </div>
                            <div id="peakHoursChart" class="chart-container">
                                <!-- Chart will be generated here -->
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Detailed Stats -->
                <div class="stats-section">
                    <div class="stats-row">
                        <!-- Spot Types Stats -->
                        <div class="card stats-card">
                            <div class="card-header">
                                <h3 class="card-title">Utilização por Tipo de Vaga</h3>
                            </div>
                            <div id="spotTypesStats" class="stats-content">
                                <!-- Stats will be populated here -->
                            </div>
                        </div>
                        
                        <!-- Performance Metrics -->
                        <div class="card stats-card">
                            <div class="card-header">
                                <h3 class="card-title">Métricas de Desempenho</h3>
                            </div>
                            <div id="performanceStats" class="stats-content">
                                <!-- Stats will be populated here -->
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Alerts -->
                <div class="alerts-section">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Alertas e Anomalias</h3>
                            <p class="card-description">Situações que merecem atenção</p>
                        </div>
                        <div id="alertsContent" class="alerts-content">
                            <!-- Alerts will be populated here -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

export function mount() {
    const store = window.app.getStore();
    const ui = window.app.getUI();
    
    // Initialize
    loadReports();
    
    // Subscribe to data changes
    store.subscribe('vagas', loadReports);
    store.subscribe('eventos', loadReports);
    
    function loadReports() {
        generateKPIs();
        generateOccupancyChart();
        generateCategoryChart();
        generateDecisionsChart();
        generatePeakHoursChart();
        generateSpotTypesStats();
        generatePerformanceStats();
        generateAlerts();
    }
    
    function generateKPIs() {
        const vagas = store.getVagas();
        const eventos = store.getEventos();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        // Calculate KPIs
        const totalVagas = vagas.length;
        const vagasOcupadas = vagas.filter(v => v.status === 'OCUPADA').length;
        const taxaOcupacao = totalVagas > 0 ? Math.round((vagasOcupadas / totalVagas) * 100) : 0;
        
        const eventosHoje = eventos.filter(e => e.timestamp >= today.getTime());
        const entradasHoje = eventosHoje.filter(e => e.decisao === 'AUTORIZADO').length;
        const negadasHoje = eventosHoje.filter(e => e.decisao === 'NEGADO').length;
        const taxaSucesso = eventosHoje.length > 0 ? 
            Math.round((entradasHoje / eventosHoje.length) * 100) : 0;
        
        // Calculate average occupancy time
        const vagasOcupadasInfo = vagas.filter(v => v.status === 'OCUPADA' && v.desde);
        const tempoMedioOcupacao = vagasOcupadasInfo.length > 0 ?
            vagasOcupadasInfo.reduce((sum, v) => sum + (Date.now() - v.desde), 0) / vagasOcupadasInfo.length :
            0;
        const horasMedias = Math.round(tempoMedioOcupacao / (60 * 60 * 1000) * 10) / 10;
        
        const kpisContainer = document.getElementById('kpisGrid');
        kpisContainer.innerHTML = `
            <div class="kpi-card occupied">
                <div class="kpi-header">
                    <span class="kpi-icon">📊</span>
                    <span class="kpi-label">Taxa de Ocupação</span>
                </div>
                <div class="kpi-value">${taxaOcupacao}%</div>
                <div class="kpi-sublabel">${vagasOcupadas}/${totalVagas} vagas</div>
            </div>
            
            <div class="kpi-card success">
                <div class="kpi-header">
                    <span class="kpi-icon">✅</span>
                    <span class="kpi-label">Entradas Hoje</span>
                </div>
                <div class="kpi-value">${entradasHoje}</div>
                <div class="kpi-sublabel">Taxa de sucesso: ${taxaSucesso}%</div>
            </div>
            
            <div class="kpi-card error">
                <div class="kpi-header">
                    <span class="kpi-icon">❌</span>
                    <span class="kpi-label">Entradas Negadas</span>
                </div>
                <div class="kpi-value">${negadasHoje}</div>
                <div class="kpi-sublabel">Hoje</div>
            </div>
            
            <div class="kpi-card info">
                <div class="kpi-header">
                    <span class="kpi-icon">⏱️</span>
                    <span class="kpi-label">Tempo Médio</span>
                </div>
                <div class="kpi-value">${horasMedias}h</div>
                <div class="kpi-sublabel">Ocupação média</div>
            </div>
        `;
    }
    
    function generateOccupancyChart() {
        const eventos = store.getEventos();
        const vagas = store.getVagas();
        const now = Date.now();
        
        // Generate hourly data for last 24 hours
        const hourlyData = [];
        for (let i = 23; i >= 0; i--) {
            const hourStart = now - (i * 60 * 60 * 1000);
            const hourEnd = hourStart + (60 * 60 * 1000);
            
            // Count entries in this hour
            const hourEntries = eventos.filter(e => 
                e.timestamp >= hourStart && e.timestamp < hourEnd && e.decisao === 'AUTORIZADO'
            ).length;
            
            // Estimate occupancy (simplified)
            const totalSpots = vagas.length;
            const occupancyRate = Math.min(100, (hourEntries / totalSpots) * 100 * 8); // Rough estimate
            
            hourlyData.push({
                hour: new Date(hourStart).getHours(),
                occupancy: Math.round(occupancyRate),
                entries: hourEntries
            });
        }
        
        const chartContainer = document.getElementById('occupancyChart');
        chartContainer.innerHTML = createLineChart(hourlyData, 'occupancy', 'Ocupação (%)', 'hour');
    }
    
    function generateCategoryChart() {
        const eventos = store.getEventos();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const eventosHoje = eventos.filter(e => 
            e.timestamp >= today.getTime() && e.decisao === 'AUTORIZADO'
        );
        
        const categoryData = eventosHoje.reduce((acc, evento) => {
            acc[evento.categoria] = (acc[evento.categoria] || 0) + 1;
            return acc;
        }, {});
        
        const chartData = Object.entries(categoryData).map(([categoria, count]) => ({
            label: getCategoriaTexto(categoria),
            value: count
        }));
        
        const chartContainer = document.getElementById('categoryChart');
        chartContainer.innerHTML = createPieChart(chartData);
    }
    
    function generateDecisionsChart() {
        const eventos = store.getEventos();
        const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
        
        const recentEvents = eventos.filter(e => e.timestamp >= sevenDaysAgo);
        
        const decisionsData = recentEvents.reduce((acc, evento) => {
            acc[evento.decisao] = (acc[evento.decisao] || 0) + 1;
            return acc;
        }, {});
        
        const chartData = Object.entries(decisionsData).map(([decisao, count]) => ({
            label: decisao,
            value: count
        }));
        
        const chartContainer = document.getElementById('decisionsChart');
        chartContainer.innerHTML = createBarChart(chartData, 'Quantidade', 'decisões');
    }
    
    function generatePeakHoursChart() {
        const eventos = store.getEventos();
        const authorized = eventos.filter(e => e.decisao === 'AUTORIZADO');
        
        // Group by hour and calculate average
        const hourlyData = Array.from({length: 24}, (_, hour) => {
            const hourEvents = authorized.filter(e => new Date(e.timestamp).getHours() === hour);
            return {
                hour,
                entries: hourEvents.length / 7 // Average over last week (rough estimate)
            };
        });
        
        const chartContainer = document.getElementById('peakHoursChart');
        chartContainer.innerHTML = createBarChart(
            hourlyData.map(d => ({ label: `${d.hour}h`, value: Math.round(d.entries) })),
            'Entradas',
            'média'
        );
    }
    
    function generateSpotTypesStats() {
        const vagas = store.getVagas();
        const statsContainer = document.getElementById('spotTypesStats');
        
        const spotTypes = ['COMUM', 'FUNCIONARIO', 'PCD', 'VISITANTE_ESPECIAL'];
        
        const statsHTML = spotTypes.map(tipo => {
            const totalTipo = vagas.filter(v => v.tipo === tipo).length;
            const ocupadasTipo = vagas.filter(v => v.tipo === tipo && v.status === 'OCUPADA').length;
            const utilizacao = totalTipo > 0 ? Math.round((ocupadasTipo / totalTipo) * 100) : 0;
            
            return `
                <div class="stat-row">
                    <div class="stat-info">
                        <span class="stat-label">${getTipoTexto(tipo)}</span>
                        <span class="stat-detail">${ocupadasTipo}/${totalTipo} vagas</span>
                    </div>
                    <div class="stat-value">${utilizacao}%</div>
                    <div class="stat-bar">
                        <div class="stat-fill" style="width: ${utilizacao}%"></div>
                    </div>
                </div>
            `;
        }).join('');
        
        statsContainer.innerHTML = statsHTML;
    }
    
    function generatePerformanceStats() {
        const eventos = store.getEventos();
        const vagas = store.getVagas();
        const statsContainer = document.getElementById('performanceStats');
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const eventosHoje = eventos.filter(e => e.timestamp >= today.getTime());
        
        // Calculate metrics
        const totalEventos = eventosHoje.length;
        const autorizados = eventosHoje.filter(e => e.decisao === 'AUTORIZADO').length;
        const negados = eventosHoje.filter(e => e.decisao === 'NEGADO').length;
        const taxaAprovacao = totalEventos > 0 ? Math.round((autorizados / totalEventos) * 100) : 0;
        
        const vagasDisponiveis = vagas.filter(v => v.status === 'LIVRE').length;
        const rotatividade = autorizados > 0 ? Math.round((autorizados / vagas.length) * 100) : 0;
        
        const tempoMedioProcessamento = '< 1s'; // Since it's automated
        
        const statsHTML = `
            <div class="performance-grid">
                <div class="performance-item">
                    <span class="performance-label">Taxa de Aprovação</span>
                    <span class="performance-value">${taxaAprovacao}%</span>
                </div>
                <div class="performance-item">
                    <span class="performance-label">Disponibilidade</span>
                    <span class="performance-value">${vagasDisponiveis} vagas</span>
                </div>
                <div class="performance-item">
                    <span class="performance-label">Rotatividade</span>
                    <span class="performance-value">${rotatividade}%</span>
                </div>
                <div class="performance-item">
                    <span class="performance-label">Tempo Processamento</span>
                    <span class="performance-value">${tempoMedioProcessamento}</span>
                </div>
                <div class="performance-item">
                    <span class="performance-label">Tentativas Negadas</span>
                    <span class="performance-value">${negados}</span>
                </div>
                <div class="performance-item">
                    <span class="performance-label">Eficiência Operacional</span>
                    <span class="performance-value">${100 - Math.round((negados / Math.max(totalEventos, 1)) * 100)}%</span>
                </div>
            </div>
        `;
        
        statsContainer.innerHTML = statsHTML;
    }
    
    function generateAlerts() {
        const vagas = store.getVagas();
        const eventos = store.getEventos();
        const alertsContainer = document.getElementById('alertsContent');
        
        const alerts = [];
        const now = Date.now();
        
        // Check for long-occupied spots
        vagas.forEach(vaga => {
            if (vaga.status === 'OCUPADA' && vaga.desde) {
                const hours = Math.floor((now - vaga.desde) / (60 * 60 * 1000));
                if (hours >= 6) {
                    alerts.push({
                        type: 'warning',
                        icon: '⚠️',
                        title: 'Vaga ocupada há muito tempo',
                        message: `Vaga ${vaga.numero} ocupada há ${hours} horas`,
                        severity: hours >= 12 ? 'high' : 'medium'
                    });
                }
            }
        });
        
        // Check for high denial rate
        const recentHour = now - (60 * 60 * 1000);
        const recentEvents = eventos.filter(e => e.timestamp >= recentHour);
        const recentDenials = recentEvents.filter(e => e.decisao === 'NEGADO').length;
        
        if (recentEvents.length > 0 && (recentDenials / recentEvents.length) > 0.3) {
            alerts.push({
                type: 'error',
                icon: '🚨',
                title: 'Alta taxa de negativas',
                message: `${Math.round((recentDenials / recentEvents.length) * 100)}% das tentativas negadas na última hora`,
                severity: 'high'
            });
        }
        
        // Check for blocked spots
        const blockedSpots = vagas.filter(v => v.status === 'BLOQUEADA').length;
        if (blockedSpots > 0) {
            alerts.push({
                type: 'info',
                icon: 'ℹ️',
                title: 'Vagas bloqueadas',
                message: `${blockedSpots} vaga(s) bloqueada(s) - verifique se ainda é necessário`,
                severity: 'low'
            });
        }
        
        // Check for low availability
        const availableSpots = vagas.filter(v => v.status === 'LIVRE').length;
        const availabilityRate = (availableSpots / vagas.length) * 100;
        
        if (availabilityRate < 10) {
            alerts.push({
                type: 'warning',
                icon: '🔴',
                title: 'Baixa disponibilidade',
                message: `Apenas ${availableSpots} vagas disponíveis (${Math.round(availabilityRate)}%)`,
                severity: 'high'
            });
        }
        
        if (alerts.length === 0) {
            alertsContainer.innerHTML = '<p class="no-data">Nenhum alerta no momento</p>';
            return;
        }
        
        // Sort by severity
        const severityOrder = { 'high': 0, 'medium': 1, 'low': 2 };
        alerts.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);
        
        const alertsHTML = alerts.map(alert => `
            <div class="alert-item ${alert.type} severity-${alert.severity}">
                <div class="alert-icon">${alert.icon}</div>
                <div class="alert-content">
                    <div class="alert-title">${alert.title}</div>
                    <div class="alert-message">${alert.message}</div>
                </div>
                <div class="alert-severity">
                    <span class="severity-badge ${alert.severity}">${getSeverityText(alert.severity)}</span>
                </div>
            </div>
        `).join('');
        
        alertsContainer.innerHTML = alertsHTML;
    }
    
    // Chart creation functions
    function createLineChart(data, valueKey, label, labelKey = 'label') {
        const width = 400;
        const height = 200;
        const margin = { top: 20, right: 20, bottom: 40, left: 50 };
        const chartWidth = width - margin.left - margin.right;
        const chartHeight = height - margin.top - margin.bottom;
        
        const maxValue = Math.max(...data.map(d => d[valueKey]), 1);
        const points = data.map((d, i) => {
            const x = margin.left + (i * (chartWidth / (data.length - 1)));
            const y = margin.top + chartHeight - ((d[valueKey] / maxValue) * chartHeight);
            return `${x},${y}`;
        }).join(' ');
        
        return `
            <svg width="${width}" height="${height}">
                <polyline points="${points}" fill="none" stroke="var(--color-blue)" stroke-width="2"/>
                ${data.map((d, i) => {
                    const x = margin.left + (i * (chartWidth / (data.length - 1)));
                    return `<text x="${x}" y="${height - 5}" text-anchor="middle" font-size="10" fill="var(--text-muted)">${d[labelKey]}h</text>`;
                }).join('')}
                <text x="${width/2}" y="${height - 5}" text-anchor="middle" font-size="12" fill="var(--text-secondary)">Hora</text>
                <text x="15" y="${height/2}" text-anchor="middle" font-size="12" fill="var(--text-secondary)" transform="rotate(-90, 15, ${height/2})">${label}</text>
            </svg>
        `;
    }
    
    function createBarChart(data, label, unit = '') {
        const width = 400;
        const height = 200;
        const margin = { top: 20, right: 20, bottom: 60, left: 40 };
        const chartWidth = width - margin.left - margin.right;
        const chartHeight = height - margin.top - margin.bottom;
        
        const maxValue = Math.max(...data.map(d => d.value), 1);
        
        const bars = data.map((d, i) => {
            const barWidth = chartWidth / data.length - 2;
            const x = margin.left + (i * (chartWidth / data.length));
            const barHeight = (d.value / maxValue) * chartHeight;
            const y = margin.top + chartHeight - barHeight;
            
            return `
                <rect x="${x}" y="${y}" width="${barWidth}" height="${barHeight}" 
                      fill="var(--color-blue)" opacity="0.8" rx="2"/>
                <text x="${x + barWidth/2}" y="${height - 25}" 
                      text-anchor="middle" font-size="8" fill="var(--text-muted)" 
                      transform="rotate(-45, ${x + barWidth/2}, ${height - 25})">
                    ${d.label}
                </text>
                <text x="${x + barWidth/2}" y="${y - 5}" 
                      text-anchor="middle" font-size="10" fill="var(--text-secondary)">
                    ${d.value}
                </text>
            `;
        }).join('');
        
        return `
            <svg width="${width}" height="${height}">
                ${bars}
                <text x="${width/2}" y="${height - 5}" text-anchor="middle" font-size="12" fill="var(--text-secondary)">${unit}</text>
                <text x="15" y="${height/2}" text-anchor="middle" font-size="12" fill="var(--text-secondary)" transform="rotate(-90, 15, ${height/2})">${label}</text>
            </svg>
        `;
    }
    
    function createPieChart(data) {
        const size = 200;
        const radius = 80;
        const centerX = size / 2;
        const centerY = size / 2;
        
        const total = data.reduce((sum, d) => sum + d.value, 0);
        if (total === 0) {
            return '<p class="no-data">Nenhum dado disponível</p>';
        }
        
        let currentAngle = 0;
        const slices = data.map((d, i) => {
            const percentage = (d.value / total) * 100;
            const angle = (d.value / total) * 360;
            const startAngle = currentAngle;
            const endAngle = currentAngle + angle;
            currentAngle += angle;
            
            const startX = centerX + radius * Math.cos((startAngle - 90) * Math.PI / 180);
            const startY = centerY + radius * Math.sin((startAngle - 90) * Math.PI / 180);
            const endX = centerX + radius * Math.cos((endAngle - 90) * Math.PI / 180);
            const endY = centerY + radius * Math.sin((endAngle - 90) * Math.PI / 180);
            
            const largeArc = angle > 180 ? 1 : 0;
            const colors = ['#1D4ED8', '#E11D48', '#10B981', '#F59E0B', '#8B5CF6'];
            
            return `
                <path d="M ${centerX} ${centerY} L ${startX} ${startY} A ${radius} ${radius} 0 ${largeArc} 1 ${endX} ${endY} Z"
                      fill="${colors[i % colors.length]}" opacity="0.8"/>
            `;
        }).join('');
        
        const legend = data.map((d, i) => {
            const colors = ['#1D4ED8', '#E11D48', '#10B981', '#F59E0B', '#8B5CF6'];
            const percentage = Math.round((d.value / total) * 100);
            
            return `
                <div class="legend-item">
                    <div class="legend-color" style="background-color: ${colors[i % colors.length]}"></div>
                    <span>${d.label}: ${d.value} (${percentage}%)</span>
                </div>
            `;
        }).join('');
        
        return `
            <div class="pie-chart-container">
                <svg width="${size}" height="${size}">
                    ${slices}
                </svg>
                <div class="chart-legend">
                    ${legend}
                </div>
            </div>
        `;
    }
    
    function getCategoriaTexto(categoria) {
        const categorias = {
            'ALUNO': 'Aluno',
            'FUNCIONARIO': 'Funcionário',
            'PCD': 'PCD',
            'VISITANTE_COMUM': 'Visitante Comum',
            'VISITANTE_ESPECIAL': 'Visitante Especial'
        };
        return categorias[categoria] || categoria;
    }
    
    function getTipoTexto(tipo) {
        const tipos = {
            'COMUM': 'Comum',
            'FUNCIONARIO': 'Funcionário',
            'PCD': 'PCD',
            'VISITANTE_ESPECIAL': 'Visitante Especial'
        };
        return tipos[tipo] || tipo;
    }
    
    function getSeverityText(severity) {
        const severities = {
            'high': 'Alta',
            'medium': 'Média',
            'low': 'Baixa'
        };
        return severities[severity] || severity;
    }
}