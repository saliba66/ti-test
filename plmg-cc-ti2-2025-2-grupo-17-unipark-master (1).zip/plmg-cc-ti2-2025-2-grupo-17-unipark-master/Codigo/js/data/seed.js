// Seed data for initial application setup
import { Usuario, Vaga, Visitante, EventoMov } from './models.js';

export function seedData(store) {
    console.log('Seeding initial data...');
    
    // Clear existing data
    store.setUsuarios([]);
    store.setVisitantes([]);
    store.setVagas([]);
    store.setEventos([]);
    
    // Create parking spots (60 total across 3 sectors)
    createParkingSpots(store);
    
    // Create sample users
    createSampleUsers(store);
    
    // Create sample visitors
    createSampleVisitors(store);
    
    // Create some sample events
    createSampleEvents(store);
    
    console.log('Seed data created successfully');
}

function createParkingSpots(store) {
    const vagas = [];
    const setores = ['A', 'B', 'C'];
    const vagasPorSetor = 20;
    
    setores.forEach(setor => {
        for (let i = 1; i <= vagasPorSetor; i++) {
            const numero = `${setor}${i.toString().padStart(2, '0')}`;
            
            // Distribute spot types according to business rules
            let tipo;
            if (i <= 14) { // 70% common spots (14/20)
                tipo = 'COMUM';
            } else if (i <= 17) { // 15% employee spots (3/20)
                tipo = 'FUNCIONARIO';
            } else if (i <= 19) { // 10% PCD spots (2/20)
                tipo = 'PCD';
            } else { // 5% special visitor spots (1/20)
                tipo = 'VISITANTE_ESPECIAL';
            }
            
            vagas.push(Vaga({
                numero,
                setor,
                tipo,
                status: 'LIVRE'
            }));
        }
    });
    
    // Occupy some spots for demonstration
    vagas[0].status = 'OCUPADA';
    vagas[0].placaAtual = 'ABC1234';
    vagas[0].desde = Date.now() - (2 * 60 * 60 * 1000); // 2 hours ago
    
    vagas[5].status = 'OCUPADA';
    vagas[5].placaAtual = 'XYZ5678';
    vagas[5].desde = Date.now() - (30 * 60 * 1000); // 30 minutes ago
    
    vagas[15].status = 'OCUPADA';
    vagas[15].placaAtual = 'DEF9012';
    vagas[15].desde = Date.now() - (4 * 60 * 60 * 1000); // 4 hours ago
    
    vagas[35].status = 'BLOQUEADA';
    vagas[35].observacoes = 'Manutenção programada';
    
    store.setVagas(vagas);
}

function createSampleUsers(store) {
    const usuarios = [
        // System users (administrators, attendants, operators)
        Usuario({
            nome: 'João Silva',
            email: 'joao.silva@universidade.edu.br',
            role: 'ADMIN',
            categoria: 'FUNCIONARIO',
            matricula: 'ADM001',
            placa: 'ADM1234'
        }),
        
        Usuario({
            nome: 'Maria Santos',
            email: 'maria.santos@universidade.edu.br',
            role: 'ATENDENTE',
            categoria: 'FUNCIONARIO',
            matricula: 'ATD001',
            placa: 'ATD5678'
        }),
        
        Usuario({
            nome: 'Pedro Costa',
            email: 'pedro.costa@universidade.edu.br',
            role: 'OPERADOR',
            categoria: 'FUNCIONARIO',
            matricula: 'OPR001',
            placa: 'OPR9012'
        }),
        
        // Students
        Usuario({
            nome: 'Ana Oliveira',
            email: 'ana.oliveira@estudante.edu.br',
            categoria: 'ALUNO',
            matricula: '2021001',
            placa: 'ABC1234'
        }),
        
        Usuario({
            nome: 'Carlos Ferreira',
            email: 'carlos.ferreira@estudante.edu.br',
            categoria: 'ALUNO',
            matricula: '2021002',
            placa: 'XYZ5678'
        }),
        
        Usuario({
            nome: 'Lucia Mendes',
            email: 'lucia.mendes@estudante.edu.br',
            categoria: 'ALUNO',
            matricula: '2020015',
            placa: 'LUC2021'
        }),
        
        // Employees
        Usuario({
            nome: 'Roberto Lima',
            email: 'roberto.lima@universidade.edu.br',
            categoria: 'FUNCIONARIO',
            matricula: 'FUNC002',
            placa: 'DEF9012'
        }),
        
        Usuario({
            nome: 'Patricia Rocha',
            email: 'patricia.rocha@universidade.edu.br',
            categoria: 'FUNCIONARIO',
            matricula: 'FUNC003',
            placa: 'PAT4567'
        }),
        
        // PCD users
        Usuario({
            nome: 'Miguel Alves',
            email: 'miguel.alves@estudante.edu.br',
            categoria: 'PCD',
            matricula: '2019020',
            placa: 'PCD1234',
            pcd: true
        }),
        
        Usuario({
            nome: 'Carmen Torres',
            email: 'carmen.torres@universidade.edu.br',
            categoria: 'PCD',
            matricula: 'FUNC004',
            placa: 'PCD5678',
            pcd: true
        })
    ];
    
    store.setUsuarios(usuarios);
}

function createSampleVisitors(store) {
    const visitantes = [
        Visitante({
            nome: 'José Pereira',
            documento: '123.456.789-01',
            placa: 'VIS1234',
            categoria: 'VISITANTE_COMUM',
            empresa: 'Empresa ABC Ltda',
            contato: '(11) 99999-1234'
        }),
        
        Visitante({
            nome: 'Sandra Machado',
            documento: '987.654.321-02',
            placa: 'VIS5678',
            categoria: 'VISITANTE_ESPECIAL',
            empresa: 'Ministério da Educação',
            contato: '(11) 88888-5678',
            observacoes: 'Reunião com Reitor'
        }),
        
        Visitante({
            nome: 'Fernando Dias',
            documento: '456.789.123-03',
            placa: 'VIS9012',
            categoria: 'VISITANTE_COMUM',
            empresa: 'Fornecedor XYZ',
            contato: '(11) 77777-9012'
        }),
        
        Visitante({
            nome: 'Mariana Castro',
            documento: '789.123.456-04',
            placa: 'ESP3456',
            categoria: 'VISITANTE_ESPECIAL',
            empresa: 'Conselho Nacional de Educação',
            contato: '(11) 66666-3456',
            observacoes: 'Comissão de avaliação'
        }),
        
        Visitante({
            nome: 'Ricardo Nunes',
            documento: '321.654.987-05',
            placa: 'VIS7890',
            categoria: 'VISITANTE_COMUM',
            empresa: 'Empresa Beta Serviços',
            contato: '(11) 55555-7890'
        })
    ];
    
    store.setVisitantes(visitantes);
}

function createSampleEvents(store) {
    const agora = Date.now();
    const eventos = [
        // Today's events
        EventoMov({
            timestamp: agora - (6 * 60 * 60 * 1000), // 6 hours ago
            placa: 'ABC1234',
            decisao: 'AUTORIZADO',
            motivo: 'Vaga A01 atribuída',
            vagaId: store.getVagas()[0]?.id,
            categoria: 'ALUNO',
            operador: 'SISTEMA'
        }),
        
        EventoMov({
            timestamp: agora - (4 * 60 * 60 * 1000), // 4 hours ago
            placa: 'DEF9012',
            decisao: 'AUTORIZADO',
            motivo: 'Vaga A16 atribuída',
            vagaId: store.getVagas()[15]?.id,
            categoria: 'FUNCIONARIO',
            operador: 'SISTEMA'
        }),
        
        EventoMov({
            timestamp: agora - (2 * 60 * 60 * 1000), // 2 hours ago
            placa: 'XYZ5678',
            decisao: 'AUTORIZADO',
            motivo: 'Vaga A06 atribuída',
            vagaId: store.getVagas()[5]?.id,
            categoria: 'ALUNO',
            operador: 'SISTEMA'
        }),
        
        EventoMov({
            timestamp: agora - (90 * 60 * 1000), // 1.5 hours ago
            placa: 'VIS1234',
            decisao: 'NEGADO',
            motivo: 'Não há vagas comuns disponíveis',
            vagaId: null,
            categoria: 'VISITANTE_COMUM',
            operador: 'SISTEMA'
        }),
        
        EventoMov({
            timestamp: agora - (60 * 60 * 1000), // 1 hour ago
            placa: 'PCD9999',
            decisao: 'AUTORIZADO',
            motivo: 'Vaga A18 atribuída',
            vagaId: store.getVagas()[17]?.id,
            categoria: 'PCD',
            operador: 'OPERADOR'
        }),
        
        EventoMov({
            timestamp: agora - (45 * 60 * 1000), // 45 minutes ago
            placa: 'INVAL',
            decisao: 'NEGADO',
            motivo: 'Placa inválida',
            vagaId: null,
            categoria: 'ALUNO',
            operador: 'SISTEMA'
        }),
        
        EventoMov({
            timestamp: agora - (30 * 60 * 1000), // 30 minutes ago
            placa: 'LUC2021',
            decisao: 'AUTORIZADO',
            motivo: 'Vaga B05 atribuída',
            vagaId: store.getVagas()[24]?.id,
            categoria: 'ALUNO',
            operador: 'SISTEMA'
        }),
        
        // Yesterday's events
        EventoMov({
            timestamp: agora - (24 * 60 * 60 * 1000) - (8 * 60 * 60 * 1000), // Yesterday morning
            placa: 'PAT4567',
            decisao: 'AUTORIZADO',
            motivo: 'Vaga A17 atribuída',
            vagaId: store.getVagas()[16]?.id,
            categoria: 'FUNCIONARIO',
            operador: 'SISTEMA'
        }),
        
        EventoMov({
            timestamp: agora - (24 * 60 * 60 * 1000) - (6 * 60 * 60 * 1000), // Yesterday morning
            placa: 'ESP3456',
            decisao: 'AUTORIZADO',
            motivo: 'Vaga A20 atribuída',
            vagaId: store.getVagas()[19]?.id,
            categoria: 'VISITANTE_ESPECIAL',
            operador: 'ATENDENTE'
        }),
        
        EventoMov({
            timestamp: agora - (24 * 60 * 60 * 1000) - (2 * 60 * 60 * 1000), // Yesterday afternoon
            placa: 'PAT4567',
            decisao: 'MANUAL',
            motivo: 'Vaga A17 liberada manualmente',
            vagaId: store.getVagas()[16]?.id,
            categoria: 'FUNCIONARIO',
            operador: 'ATENDENTE'
        }),
        
        // Some denied entries
        EventoMov({
            timestamp: agora - (3 * 60 * 60 * 1000), // 3 hours ago
            placa: 'CHEIA001',
            decisao: 'NEGADO',
            motivo: 'Estacionamento lotado',
            vagaId: null,
            categoria: 'VISITANTE_COMUM',
            operador: 'SISTEMA'
        }),
        
        EventoMov({
            timestamp: agora - (5 * 60 * 60 * 1000), // 5 hours ago
            placa: 'ABC1234',
            decisao: 'NEGADO',
            motivo: 'Veículo já está no estacionamento',
            vagaId: store.getVagas()[0]?.id,
            categoria: 'ALUNO',
            operador: 'SISTEMA'
        })
    ];
    
    store.setEventos(eventos);
}