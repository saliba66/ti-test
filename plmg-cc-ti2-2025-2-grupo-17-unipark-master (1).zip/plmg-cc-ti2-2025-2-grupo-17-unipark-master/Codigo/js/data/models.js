// Data models and validation functions

export const Roles = ["ADMIN", "ATENDENTE", "OPERADOR"];

export const Categorias = [
    "ALUNO",
    "FUNCIONARIO", 
    "PCD",
    "VISITANTE_COMUM",
    "VISITANTE_ESPECIAL"
];

export const StatusVaga = ["LIVRE", "OCUPADA", "BLOQUEADA"];

export const TiposVaga = ["COMUM", "FUNCIONARIO", "PCD", "VISITANTE_ESPECIAL"];

export const Setores = ["A", "B", "C"];

// User model - both system users and parking users
export function Usuario({
    id = null,
    nome = '',
    email = '',
    role = null, // For system users
    categoria = '',
    matricula = '',
    placa = '',
    pcd = false,
    ativo = true,
    criadoEm = null
}) {
    return {
        id,
        nome,
        email,
        role,
        categoria,
        matricula,
        placa: placa.toUpperCase(),
        pcd: !!pcd,
        ativo,
        criadoEm: criadoEm || Date.now()
    };
}

// Parking spot model
export function Vaga({
    id = null,
    numero = '',
    setor = 'A',
    tipo = 'COMUM',
    status = 'LIVRE',
    placaAtual = null,
    desde = null,
    observacoes = ''
}) {
    return {
        id,
        numero,
        setor,
        tipo,
        status,
        placaAtual,
        desde,
        observacoes
    };
}

// Visitor model
export function Visitante({
    id = null,
    nome = '',
    documento = '',
    placa = '',
    categoria = 'VISITANTE_COMUM',
    empresa = '',
    contato = '',
    observacoes = '',
    ativo = true,
    criadoEm = null
}) {
    return {
        id,
        nome,
        documento,
        placa: placa.toUpperCase(),
        categoria,
        empresa,
        contato,
        observacoes,
        ativo,
        criadoEm: criadoEm || Date.now()
    };
}

// Movement event model
export function EventoMov({
    id = null,
    timestamp = null,
    placa = '',
    decisao = 'AUTORIZADO', // AUTORIZADO | NEGADO | MANUAL
    motivo = '',
    vagaId = null,
    categoria = '',
    operador = 'SISTEMA'
}) {
    return {
        id,
        timestamp: timestamp || Date.now(),
        placa: placa.toUpperCase(),
        decisao,
        motivo,
        vagaId,
        categoria,
        operador
    };
}

// Validation functions
export function validarPlaca(placa) {
    if (!placa) return false;
    
    const normalizada = placa.toUpperCase().replace(/[^A-Z0-9]/g, '');
    
    // Formato antigo: AAA-0000
    const formatoAntigo = /^[A-Z]{3}[0-9]{4}$/.test(normalizada);
    
    // Formato Mercosul: AAA0A00
    const formatoMercosul = /^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(normalizada);
    
    return formatoAntigo || formatoMercosul;
}

export function validarEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

export function validarCPF(cpf) {
    // Remove caracteres não numéricos
    const numeros = cpf.replace(/[^\d]/g, '');
    
    // Verifica se tem 11 dígitos
    if (numeros.length !== 11) return false;
    
    // Verifica se todos os dígitos são iguais
    if (/^(\d)\1{10}$/.test(numeros)) return false;
    
    // Validação do primeiro dígito verificador
    let soma = 0;
    for (let i = 0; i < 9; i++) {
        soma += parseInt(numeros[i]) * (10 - i);
    }
    let primeiroDigito = 11 - (soma % 11);
    if (primeiroDigito >= 10) primeiroDigito = 0;
    if (parseInt(numeros[9]) !== primeiroDigito) return false;
    
    // Validação do segundo dígito verificador
    soma = 0;
    for (let i = 0; i < 10; i++) {
        soma += parseInt(numeros[i]) * (11 - i);
    }
    let segundoDigito = 11 - (soma % 11);
    if (segundoDigito >= 10) segundoDigito = 0;
    if (parseInt(numeros[10]) !== segundoDigito) return false;
    
    return true;
}

export function formatarPlaca(placa) {
    if (!placa) return '';
    
    const normalizada = placa.toUpperCase().replace(/[^A-Z0-9]/g, '');
    
    if (normalizada.length === 7) {
        // Formato antigo: AAA-0000
        return `${normalizada.slice(0, 3)}-${normalizada.slice(3)}`;
    } else if (normalizada.length === 8) {
        // Formato Mercosul: AAA-0A00
        return `${normalizada.slice(0, 3)}-${normalizada.slice(3, 4)}${normalizada.slice(4, 5)}${normalizada.slice(5)}`;
    }
    
    return placa;
}

export function formatarCPF(cpf) {
    const numeros = cpf.replace(/[^\d]/g, '');
    return numeros.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}

export function formatarTelefone(telefone) {
    const numeros = telefone.replace(/[^\d]/g, '');
    
    if (numeros.length === 10) {
        return numeros.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
    } else if (numeros.length === 11) {
        return numeros.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
    
    return telefone;
}

// Business rules
export const RegrasNegocio = {
    // Priority order for spot assignment
    prioridadeVagas: {
        'FUNCIONARIO': ['FUNCIONARIO', 'COMUM'],
        'PCD': ['PCD', 'COMUM'],
        'VISITANTE_ESPECIAL': ['VISITANTE_ESPECIAL', 'COMUM'],
        'ALUNO': ['COMUM'],
        'VISITANTE_COMUM': ['COMUM']
    },
    
    // Maximum occupancy time (in milliseconds)
    tempoMaximoOcupacao: {
        'FUNCIONARIO': 8 * 60 * 60 * 1000, // 8 hours
        'PCD': 8 * 60 * 60 * 1000, // 8 hours
        'VISITANTE_ESPECIAL': 4 * 60 * 60 * 1000, // 4 hours
        'ALUNO': 4 * 60 * 60 * 1000, // 4 hours
        'VISITANTE_COMUM': 2 * 60 * 60 * 1000 // 2 hours
    },
    
    // Default spot distribution
    distribuicaoVagas: {
        'COMUM': 0.7, // 70%
        'FUNCIONARIO': 0.15, // 15%
        'PCD': 0.10, // 10%
        'VISITANTE_ESPECIAL': 0.05 // 5%
    }
};

// Status translations
export const StatusTexto = {
    'LIVRE': 'Livre',
    'OCUPADA': 'Ocupada',
    'BLOQUEADA': 'Bloqueada'
};

export const TipoTexto = {
    'COMUM': 'Comum',
    'FUNCIONARIO': 'Funcionário',
    'PCD': 'PCD',
    'VISITANTE_ESPECIAL': 'Visitante Especial'
};

export const CategoriaTexto = {
    'ALUNO': 'Aluno',
    'FUNCIONARIO': 'Funcionário',
    'PCD': 'PCD',
    'VISITANTE_COMUM': 'Visitante Comum',
    'VISITANTE_ESPECIAL': 'Visitante Especial'
};

export const DecisaoTexto = {
    'AUTORIZADO': 'Autorizado',
    'NEGADO': 'Negado',
    'MANUAL': 'Manual'
};

// Color mappings for UI
export const CoresStatus = {
    'LIVRE': '#10B981',
    'OCUPADA': '#E11D48',
    'BLOQUEADA': '#6B7280'
};

export const CoresTipo = {
    'COMUM': '#10B981',
    'FUNCIONARIO': '#7C3AED',
    'PCD': '#1D4ED8',
    'VISITANTE_ESPECIAL': '#F59E0B'
};