export function render() {
  return `<section><h1>404</h1><p>Página não encontrada</p></section>`;
}
